'use strict';

/**
 * سوق حفر الباطن — سيرفر الموقع وواجهة الإدارة.
 * Node.js فقط، بدون أي حزم خارجية.
 *
 * التشغيل:  node server.js
 * الموقع:   http://localhost:8080
 * الإدارة:  http://localhost:8080/admin
 */

const http = require('http');
const fs = require('fs');
const path = require('path');
const os = require('os');
const crypto = require('crypto');

const db = require('./db');

const PORT = Number(process.env.PORT) || 8080;
const PUBLIC_DIR = path.join(__dirname, 'public');
const UPLOAD_DIR = path.join(PUBLIC_DIR, 'uploads');
const SECRET_FILE = path.join(__dirname, 'data', 'secret.key');
const SESSION_HOURS = 12;

fs.mkdirSync(UPLOAD_DIR, { recursive: true });

/* ------------------------------- مفتاح الجلسات ------------------------------ */

function loadSecret() {
  fs.mkdirSync(path.dirname(SECRET_FILE), { recursive: true });
  if (fs.existsSync(SECRET_FILE)) return fs.readFileSync(SECRET_FILE, 'utf8').trim();
  const secret = crypto.randomBytes(32).toString('hex');
  fs.writeFileSync(SECRET_FILE, secret, { mode: 0o600 });
  return secret;
}
const SECRET = loadSecret();

function sign(payload) {
  return crypto.createHmac('sha256', SECRET).update(payload).digest('hex');
}

/** بصمة قصيرة من تجزئة الرمز: تغيير الرمز يُبطل كل الجلسات القديمة. */
function sessionFingerprint() {
  return db.passwordFingerprint().slice(0, 24);
}

/* مخزن الجلسات في الذاكرة: الجلسة تُلغى عند الخروج أو انتهاء المدة أو تغيير الرمز. */
const SESSION_IDLE_MS = 60 * 60 * 1000; // قفل تلقائي بعد ساعة بدون نشاط
const sessions = new Map();

function safeEqual(a, b) {
  const bufA = Buffer.from(String(a || ''), 'utf8');
  const bufB = Buffer.from(String(b || ''), 'utf8');
  return bufA.length === bufB.length && crypto.timingSafeEqual(bufA, bufB);
}

function makeSession() {
  const sid = crypto.randomBytes(24).toString('hex');
  const now = Date.now();
  sessions.set(sid, { created: now, lastSeen: now, fingerprint: sessionFingerprint() });
  // حد أعلى بسيط يمنع تضخم الذاكرة من محاولات متكررة.
  if (sessions.size > 100) {
    const oldest = [...sessions.entries()].sort((a, b) => a[1].lastSeen - b[1].lastSeen)[0];
    if (oldest) sessions.delete(oldest[0]);
  }
  return { sid, token: sid + '.' + sign(sid), maxAge: SESSION_HOURS * 3600 };
}

function readSession(req) {
  const raw = parseCookies(req)['hb_admin'];
  if (!raw) return null;
  const parts = raw.split('.');
  if (parts.length !== 2) return null;
  const [sid, mac] = parts;
  if (!sid || !mac) return null;
  if (!safeEqual(mac, sign(sid))) return null;

  const rec = sessions.get(sid);
  if (!rec) return null;
  if (rec.fingerprint !== sessionFingerprint()) {
    sessions.delete(sid);
    return null;
  }

  const now = Date.now();
  const expired = now - rec.created > SESSION_HOURS * 3600 * 1000;
  const idle = now - rec.lastSeen > SESSION_IDLE_MS;
  if (expired || idle) {
    sessions.delete(sid);
    return null;
  }

  rec.lastSeen = now; // تمديد مهلة الخمول مع كل طلب موثّق
  return { sid, expires: rec.created + SESSION_HOURS * 3600 * 1000 };
}

function destroySession(req) {
  const raw = parseCookies(req)['hb_admin'];
  if (!raw) return;
  const sid = raw.split('.')[0];
  if (sid) sessions.delete(sid);
}

function destroyAllSessions() {
  sessions.clear();
}

/** خصائص الكوكي: HttpOnly دائماً، وSecure تلقائياً خلف HTTPS. */
function cookieFlags(req) {
  const proto = String(req.headers['x-forwarded-proto'] || '').split(',')[0].trim();
  const secure = req.socket.encrypted || proto === 'https';
  return 'HttpOnly; SameSite=Strict; Path=/' + (secure ? '; Secure' : '');
}

/* --------------------------------- أدوات ---------------------------------- */

function parseCookies(req) {
  const out = {};
  (req.headers.cookie || '').split(';').forEach((part) => {
    const i = part.indexOf('=');
    if (i === -1) return;
    const key = part.slice(0, i).trim();
    const value = part.slice(i + 1).trim();
    if (!key) return;
    try {
      out[key] = decodeURIComponent(value);
    } catch (err) {
      out[key] = value;
    }
  });
  return out;
}

function sendJson(res, status, data, extraHeaders) {
  const body = JSON.stringify(data);
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
    ...(extraHeaders || {})
  });
  res.end(body);
}

function readBody(req, limit = 8 * 1024 * 1024) {
  return new Promise((resolve, reject) => {
    let size = 0;
    const chunks = [];
    req.on('data', (chunk) => {
      size += chunk.length;
      if (size > limit) {
        reject(new Error('الحجم أكبر من المسموح'));
        req.destroy();
        return;
      }
      chunks.push(chunk);
    });
    req.on('end', () => {
      if (!chunks.length) return resolve({});
      try {
        resolve(JSON.parse(Buffer.concat(chunks).toString('utf8')));
      } catch (err) {
        reject(new Error('صيغة JSON غير صحيحة'));
      }
    });
    req.on('error', reject);
  });
}

/* --------------------------- حماية محاولات الدخول --------------------------- */

const attempts = new Map();
const WINDOW_MS = 15 * 60 * 1000;
const MAX_ATTEMPTS = 5;

/** عنوان الزائر الحقيقي — لا يثق بـ X-Forwarded-For إلا عند تشغيل TRUST_PROXY. */
function clientIp(req) {
  if (process.env.TRUST_PROXY === '1') {
    const forwarded = String(req.headers['x-forwarded-for'] || '').split(',')[0].trim();
    if (forwarded) return forwarded;
  }
  return req.socket.remoteAddress || 'unknown';
}

function loginBlocked(ip) {
  const rec = attempts.get(ip);
  if (!rec) return false;
  if (Date.now() - rec.first > WINDOW_MS) {
    attempts.delete(ip);
    return false;
  }
  return rec.count >= MAX_ATTEMPTS;
}

function noteFailure(ip) {
  const rec = attempts.get(ip);
  if (!rec || Date.now() - rec.first > WINDOW_MS) {
    attempts.set(ip, { first: Date.now(), count: 1 });
  } else {
    rec.count += 1;
  }
  if (attempts.size > 5000) {
    const cutoff = Date.now() - WINDOW_MS;
    for (const [key, value] of attempts) {
      if (value.first < cutoff) attempts.delete(key);
    }
  }
}

/* ------------------------- حماية النماذج العامة ---------------------------- */

const publicHits = new Map();

function publicRateLimited(ip, key, max, windowMs) {
  const mapKey = key + ':' + ip;
  const now = Date.now();
  const rec = publicHits.get(mapKey);
  if (!rec || now - rec.first > windowMs) {
    publicHits.set(mapKey, { first: now, count: 1 });
    if (publicHits.size > 5000) {
      for (const [k, v] of publicHits) {
        if (now - v.first > 60 * 60 * 1000) publicHits.delete(k);
      }
    }
    return false;
  }
  rec.count += 1;
  return rec.count > max;
}

/** يتحقق من البصمة الحقيقية للملف وليس فقط من الامتداد أو نوع البيانات المعلن. */
function sniffImageType(buffer) {
  if (buffer.length >= 8 && buffer[0] === 0x89 && buffer[1] === 0x50 && buffer[2] === 0x4e && buffer[3] === 0x47) {
    return 'png';
  }
  if (buffer.length >= 3 && buffer[0] === 0xff && buffer[1] === 0xd8 && buffer[2] === 0xff) {
    return 'jpg';
  }
  if (
    buffer.length >= 12 &&
    buffer.toString('ascii', 0, 4) === 'RIFF' &&
    buffer.toString('ascii', 8, 12) === 'WEBP'
  ) {
    return 'webp';
  }
  return null;
}

function saveUploadedImage(dataUrl, maxBytes) {
  const match = /^data:image\/(png|jpeg|jpg|webp);base64,([A-Za-z0-9+/=\s]+)$/i.exec(String(dataUrl || ''));
  if (!match) throw new Error('صيغة الصورة غير مدعومة (PNG أو JPG أو WEBP)');
  const declared = match[1].toLowerCase() === 'jpeg' ? 'jpg' : match[1].toLowerCase();
  const buffer = Buffer.from(match[2].replace(/\s+/g, ''), 'base64');
  if (!buffer.length) throw new Error('ملف الصورة فارغ');
  if (buffer.length > maxBytes) throw new Error('حجم الصورة أكبر من ' + Math.round(maxBytes / (1024 * 1024)) + ' ميجا');

  const actual = sniffImageType(buffer);
  if (!actual || actual !== declared) throw new Error('محتوى الملف لا يطابق صيغة صورة صحيحة');

  const name = db.uid('img') + '.' + actual;
  fs.writeFileSync(path.join(UPLOAD_DIR, name), buffer);
  return '/uploads/' + name;
}

/* --------------------------------- الملفات -------------------------------- */

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.webmanifest': 'application/manifest+json; charset=utf-8',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.webp': 'image/webp',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon',
  '.txt': 'text/plain; charset=utf-8'
};

const BLOCKED_STATIC_NAMES = new Set([
  'db.json',
  'secret.key',
  'server.js',
  'db.js',
  'package.json',
  'package-lock.json',
  '.env',
  '.gitignore',
  '.htaccess'
]);

/** يمنع الوصول لأي ملف حساس أو مخفي من خلال السيرفر الثابت. */
function isBlockedStaticPath(rel) {
  const parts = rel.split(/[\\/]+/).filter(Boolean);
  if (parts.some((part) => part.startsWith('.'))) return true;
  const base = (parts[parts.length - 1] || '').toLowerCase();
  if (BLOCKED_STATIC_NAMES.has(base)) return true;
  if (/\.(env|key|pem|crt|log|sql|bak|ini|conf|md)$/i.test(base)) return true;
  return false;
}

function serveStatic(req, res, urlPath) {
  let rel = urlPath;
  if (rel === '/' || rel === '') rel = '/index.html';
  if (rel === '/admin' || rel === '/admin/') rel = '/admin.html';

  if (isBlockedStaticPath(rel)) {
    res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
    res.end('Not found');
    return;
  }

  const filePath = path.normalize(path.join(PUBLIC_DIR, rel));
  if (!filePath.startsWith(PUBLIC_DIR + path.sep)) {
    res.writeHead(403, { 'Content-Type': 'text/plain; charset=utf-8' });
    res.end('Forbidden');
    return;
  }

  fs.readFile(filePath, (err, data) => {
    if (err) {
      // مسارات الواجهة العامة (hash routing) ترجع الصفحة الرئيسية
      if (!path.extname(rel)) {
        fs.readFile(path.join(PUBLIC_DIR, 'index.html'), (e2, home) => {
          if (e2) {
            res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
            res.end('Not found');
            return;
          }
          res.writeHead(200, { 'Content-Type': MIME['.html'] });
          res.end(home);
        });
        return;
      }
      res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
      res.end('Not found');
      return;
    }
    const ext = path.extname(filePath).toLowerCase();
    const isAsset = ['.png', '.jpg', '.jpeg', '.webp', '.svg', '.ico'].includes(ext);
    const isAdminPage = rel === '/admin.html';
    res.writeHead(200, {
      'Content-Type': MIME[ext] || 'application/octet-stream',
      'Cache-Control': isAdminPage ? 'no-store' : isAsset ? 'public, max-age=86400' : 'no-cache',
      'X-Content-Type-Options': 'nosniff',
      'X-Frame-Options': 'DENY',
      'Referrer-Policy': 'strict-origin-when-cross-origin'
    });
    res.end(data);
  });
}

/* --------------------------------- المسارات -------------------------------- */

const routes = [];

function route(method, pattern, handler, opts = {}) {
  routes.push({ method, pattern, handler, auth: !!opts.auth });
}

/* --- عام --- */

route('GET', /^\/api\/bootstrap$/, async (req, res) => {
  sendJson(res, 200, db.publicData());
});

route('GET', /^\/api\/revision$/, async (req, res) => {
  sendJson(res, 200, { revision: db.revision() });
});

route('GET', /^\/api\/store\/([\w-]+)$/, async (req, res, params) => {
  const data = db.publicData();
  const store = data.stores.find((s) => s.id === params[0]);
  if (!store) return sendJson(res, 404, { error: 'المحل غير موجود أو اشتراكه منتهي' });
  sendJson(res, 200, {
    store,
    products: data.products.filter((p) => p.storeId === store.id)
  });
});

route('POST', /^\/api\/orders$/, async (req, res) => {
  const ip = clientIp(req);
  if (publicRateLimited(ip, 'order', 10, 60 * 60 * 1000)) {
    return sendJson(res, 429, { error: 'أرسلت طلبات كثيرة، حاول بعد ساعة.' });
  }
  const body = await readBody(req);
  try {
    const order = db.createOrder(body);
    sendJson(res, 201, {
      ok: true,
      order: {
        id: order.id,
        number: order.number,
        total: order.total,
        items: order.items,
        createdAt: order.createdAt
      }
    });
  } catch (err) {
    sendJson(res, 400, { error: err.message });
  }
});

/* --- طلبات العملاء (إضافة منتج أو صورة) --- */

route('POST', /^\/api\/submission-upload$/, async (req, res) => {
  const ip = clientIp(req);
  if (publicRateLimited(ip, 'upload', 12, 60 * 60 * 1000)) {
    return sendJson(res, 429, { error: 'محاولات رفع كثيرة، حاول بعد قليل.' });
  }
  const body = await readBody(req);
  try {
    sendJson(res, 200, { ok: true, url: saveUploadedImage(body.data, 3 * 1024 * 1024) });
  } catch (err) {
    sendJson(res, 400, { error: err.message });
  }
});

route('POST', /^\/api\/submissions$/, async (req, res) => {
  const ip = clientIp(req);
  if (publicRateLimited(ip, 'submission', 6, 60 * 60 * 1000)) {
    return sendJson(res, 429, { error: 'أرسلت طلبات كثيرة، حاول بعد ساعة.' });
  }
  const body = await readBody(req);
  try {
    const submission = db.createSubmission(body);
    sendJson(res, 201, { ok: true, submission: { id: submission.id, status: submission.status } });
  } catch (err) {
    sendJson(res, 400, { error: err.message });
  }
});

/* --- الإدارة --- */

route('POST', /^\/api\/admin\/login$/, async (req, res) => {
  const ip = clientIp(req);
  if (loginBlocked(ip)) {
    return sendJson(
      res,
      429,
      { error: 'محاولات كثيرة. انتظر ١٥ دقيقة ثم حاول مرة أخرى.' },
      { 'Retry-After': String(Math.ceil(WINDOW_MS / 1000)) }
    );
  }
  const body = await readBody(req);
  const password = String(body.password || '');
  if (!password || !db.checkPassword(password)) {
    noteFailure(ip);
    return sendJson(res, 401, { error: 'الرمز السري غير صحيح' });
  }
  attempts.delete(ip);
  const session = makeSession();
  sendJson(
    res,
    200,
    { ok: true },
    { 'Set-Cookie': `hb_admin=${session.token}; ${cookieFlags(req)}; Max-Age=${session.maxAge}` }
  );
});

route('POST', /^\/api\/admin\/logout$/, async (req, res) => {
  destroySession(req);
  sendJson(res, 200, { ok: true }, { 'Set-Cookie': `hb_admin=; ${cookieFlags(req)}; Max-Age=0` });
});

route('GET', /^\/api\/admin\/session$/, async (req, res) => {
  const session = readSession(req);
  sendJson(res, 200, { authenticated: !!session });
}, { auth: false });

route('GET', /^\/api\/admin\/data$/, async (req, res) => {
  sendJson(res, 200, db.adminData());
}, { auth: true });

route('GET', /^\/api\/admin\/notifications$/, async (req, res) => {
  sendJson(res, 200, db.notifications());
}, { auth: true });

route('POST', /^\/api\/admin\/store\/([\w-]+)\/renew$/, async (req, res, params) => {
  const body = await readBody(req);
  try {
    sendJson(res, 200, { ok: true, store: db.renewStore(params[0], body.months) });
  } catch (err) {
    sendJson(res, 400, { error: err.message });
  }
}, { auth: true });

route('POST', /^\/api\/admin\/submission\/([\w-]+)\/approve$/, async (req, res, params) => {
  try {
    sendJson(res, 200, { ok: true, submission: db.approveSubmission(params[0]) });
  } catch (err) {
    sendJson(res, 400, { error: err.message });
  }
}, { auth: true });

route('POST', /^\/api\/admin\/submission\/([\w-]+)\/reject$/, async (req, res, params) => {
  const body = await readBody(req);
  try {
    sendJson(res, 200, { ok: true, submission: db.rejectSubmission(params[0], body.reason) });
  } catch (err) {
    sendJson(res, 400, { error: err.message });
  }
}, { auth: true });

route('DELETE', /^\/api\/admin\/submission\/([\w-]+)$/, async (req, res, params) => {
  try {
    db.deleteSubmission(params[0]);
    sendJson(res, 200, { ok: true });
  } catch (err) {
    sendJson(res, 400, { error: err.message });
  }
}, { auth: true });

route('POST', /^\/api\/admin\/store$/, async (req, res) => {
  const body = await readBody(req);
  try {
    sendJson(res, 200, { ok: true, store: db.upsertStore(body) });
  } catch (err) {
    sendJson(res, 400, { error: err.message });
  }
}, { auth: true });

route('DELETE', /^\/api\/admin\/store\/([\w-]+)$/, async (req, res, params) => {
  try {
    db.deleteStore(params[0]);
    sendJson(res, 200, { ok: true });
  } catch (err) {
    sendJson(res, 400, { error: err.message });
  }
}, { auth: true });

route('POST', /^\/api\/admin\/product$/, async (req, res) => {
  const body = await readBody(req);
  try {
    sendJson(res, 200, { ok: true, product: db.upsertProduct(body) });
  } catch (err) {
    sendJson(res, 400, { error: err.message });
  }
}, { auth: true });

route('DELETE', /^\/api\/admin\/product\/([\w-]+)$/, async (req, res, params) => {
  try {
    db.deleteProduct(params[0]);
    sendJson(res, 200, { ok: true });
  } catch (err) {
    sendJson(res, 400, { error: err.message });
  }
}, { auth: true });

route('POST', /^\/api\/admin\/category$/, async (req, res) => {
  const body = await readBody(req);
  try {
    sendJson(res, 200, { ok: true, category: db.upsertCategory(body) });
  } catch (err) {
    sendJson(res, 400, { error: err.message });
  }
}, { auth: true });

route('DELETE', /^\/api\/admin\/category\/([\w-]+)$/, async (req, res, params) => {
  try {
    db.deleteCategory(params[0]);
    sendJson(res, 200, { ok: true });
  } catch (err) {
    sendJson(res, 400, { error: err.message });
  }
}, { auth: true });

route('POST', /^\/api\/admin\/banner$/, async (req, res) => {
  const body = await readBody(req);
  try {
    sendJson(res, 200, { ok: true, banner: db.upsertBanner(body) });
  } catch (err) {
    sendJson(res, 400, { error: err.message });
  }
}, { auth: true });

route('DELETE', /^\/api\/admin\/banner\/([\w-]+)$/, async (req, res, params) => {
  try {
    db.deleteBanner(params[0]);
    sendJson(res, 200, { ok: true });
  } catch (err) {
    sendJson(res, 400, { error: err.message });
  }
}, { auth: true });

route('POST', /^\/api\/admin\/order\/([\w-]+)\/status$/, async (req, res, params) => {
  const body = await readBody(req);
  try {
    sendJson(res, 200, { ok: true, order: db.setOrderStatus(params[0], body.status) });
  } catch (err) {
    sendJson(res, 400, { error: err.message });
  }
}, { auth: true });

route('POST', /^\/api\/admin\/settings$/, async (req, res) => {
  const body = await readBody(req);
  sendJson(res, 200, { ok: true, settings: db.updateSettings(body) });
}, { auth: true });

route('POST', /^\/api\/admin\/password$/, async (req, res) => {
  const body = await readBody(req);
  const password = String(body.password || '');
  if (password.length < 8) return sendJson(res, 400, { error: 'الرمز السري يجب أن يكون ٨ أحرف على الأقل' });
  if (password === 'admin1234') return sendJson(res, 400, { error: 'لا تستخدم الرمز الافتراضي' });
  db.setPassword(password);
  // إبطال كل الجلسات القديمة ثم إصدار جلسة جديدة لهذا الجهاز فقط.
  destroyAllSessions();
  const session = makeSession();
  sendJson(
    res,
    200,
    { ok: true },
    { 'Set-Cookie': `hb_admin=${session.token}; ${cookieFlags(req)}; Max-Age=${session.maxAge}` }
  );
}, { auth: true });

route('POST', /^\/api\/admin\/upload$/, async (req, res) => {
  const body = await readBody(req);
  try {
    sendJson(res, 200, { ok: true, url: saveUploadedImage(body.data, 4 * 1024 * 1024) });
  } catch (err) {
    sendJson(res, 400, { error: err.message });
  }
}, { auth: true });

/* ------------------------------- حماية CSRF ------------------------------- */

/** الطلبات المتغيّرة على لوحة التحكم تحتاج ترويسة AJAX + نفس الأصل. */
function csrfOk(req) {
  if (String(req.headers['x-requested-with'] || '').toLowerCase() !== 'xmlhttprequest') return false;
  const origin = req.headers.origin;
  if (!origin) return true;
  try {
    return new URL(origin).host === req.headers.host;
  } catch (err) {
    return false;
  }
}

/* --------------------------------- السيرفر -------------------------------- */

const server = http.createServer(async (req, res) => {
  let urlPath;
  try {
    urlPath = decodeURIComponent((req.url || '/').split('?')[0]);
  } catch (err) {
    res.writeHead(400, { 'Content-Type': 'text/plain; charset=utf-8' });
    res.end('Bad request');
    return;
  }

  // ترويسات أمان عامة لكل الاستجابات
  const proto = String(req.headers['x-forwarded-proto'] || '').split(',')[0].trim();
  const isHttps = !!req.socket.encrypted || proto === 'https';

  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  res.setHeader('Permissions-Policy', 'geolocation=(), microphone=(), camera=()');
  res.setHeader(
    'Content-Security-Policy',
    [
      "default-src 'self'",
      "base-uri 'self'",
      "object-src 'none'",
      "frame-ancestors 'none'",
      "form-action 'self'",
      "script-src 'self'",
      "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com",
      "font-src 'self' https://fonts.gstatic.com data:",
      "img-src 'self' data: https:",
      "connect-src 'self'",
      "manifest-src 'self'"
    ].join('; ')
  );
  if (isHttps) res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');

  if (urlPath.startsWith('/api/')) {
    const method = req.method === 'HEAD' ? 'GET' : req.method;
    const mutating = ['POST', 'PUT', 'PATCH', 'DELETE'].includes(req.method);
    if (mutating && urlPath.startsWith('/api/admin/') && !csrfOk(req)) {
      return sendJson(res, 403, { error: 'طلب غير موثوق. أعد تحميل الصفحة وحاول مرة أخرى.' });
    }
    for (const r of routes) {
      if (r.method !== method) continue;
      const match = r.pattern.exec(urlPath);
      if (!match) continue;
      if (r.auth && !readSession(req)) {
        return sendJson(res, 401, { error: 'انتهت الجلسة، سجّل الدخول من جديد' });
      }
      try {
        await r.handler(req, res, match.slice(1));
      } catch (err) {
        if (!res.headersSent) sendJson(res, 500, { error: err.message || 'خطأ غير متوقع' });
      }
      return;
    }
    return sendJson(res, 404, { error: 'المسار غير موجود' });
  }

  if (req.method !== 'GET' && req.method !== 'HEAD') {
    res.writeHead(405, { 'Content-Type': 'text/plain; charset=utf-8' });
    res.end('Method not allowed');
    return;
  }

  serveStatic(req, res, urlPath);
});

server.on('error', (err) => {
  if (err.code === 'EADDRINUSE') {
    console.log('المنفذ ' + PORT + ' مستخدم. جرّب: set PORT=8090 && node server.js');
  } else {
    console.log('خطأ في السيرفر: ' + err.message);
  }
  process.exit(1);
});

server.listen(PORT, '0.0.0.0', () => {
  const ips = [];
  const nets = os.networkInterfaces();
  Object.keys(nets).forEach((name) => {
    (nets[name] || []).forEach((net) => {
      if (net.family === 'IPv4' && !net.internal) ips.push(net.address);
    });
  });

  console.log('');
  console.log('  سوق حفر الباطن — يعمل الآن');
  console.log('  الموقع:   http://localhost:' + PORT);
  console.log('  الإدارة:  http://localhost:' + PORT + '/admin');
  ips.forEach((ip) => console.log('  الجوال:   http://' + ip + ':' + PORT + '   (نفس الشبكة)'));
  console.log('');
  console.log('  الرمز السري الافتراضي للوحة التحكم: admin1234');
  console.log('  غيّره من: الإدارة ← الإعدادات');
  console.log('');
});

['SIGINT', 'SIGTERM'].forEach((sig) => {
  process.on(sig, () => {
    db.flush();
    process.exit(0);
  });
});
