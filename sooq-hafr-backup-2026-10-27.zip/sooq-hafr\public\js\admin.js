'use strict';

/* ===========================================================
   لوحة تحكم سوق حفر الباطن
   =========================================================== */

const $ = (sel, root = document) => root.querySelector(sel);
const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));

const state = {
  data: null,
  tab: 'overview',
  search: ''
};

let lastPending = null;

const STATUS = {
  new: { label: 'جديد', cls: 'warn' },
  contacted: { label: 'تم التواصل', cls: 'info' },
  done: { label: 'مكتمل', cls: 'ok' },
  cancelled: { label: 'ملغي', cls: 'off' }
};

const SUB_STATUS = {
  pending: { label: 'بانتظار الموافقة', cls: 'warn' },
  approved: { label: 'تمت الموافقة', cls: 'ok' },
  rejected: { label: 'مرفوض', cls: 'off' }
};

const SUB_TYPE = {
  product: { label: 'منتج جديد', icon: '📦' },
  image: { label: 'صورة منتج', icon: '🖼️' }
};

const THEME_PRESETS = [
  { name: 'زمردي', primary: '#0f7350', accent: '#f5a524' },
  { name: 'أزرق', primary: '#1d4ed8', accent: '#f59e0b' },
  { name: 'بنفسجي', primary: '#6d28d9', accent: '#f59e0b' },
  { name: 'عنابي', primary: '#9f1239', accent: '#eab308' },
  { name: 'فحمي', primary: '#1f2937', accent: '#f59e0b' }
];

/* -------------------------------- أدوات عامة ------------------------------- */

function escapeHtml(value) {
  return String(value == null ? '' : value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

function money(n) {
  const num = Number(n) || 0;
  const text = num % 1 === 0 ? String(num) : num.toFixed(2);
  return text.replace(/\B(?=(\d{3})+(?!\d))/g, ',');
}

function fmtDate(value) {
  if (!value) return '—';
  const d = new Date(value);
  if (Number.isNaN(d.getTime())) return '—';
  return d.toLocaleDateString('ar-SA-u-ca-gregory-nu-latn', { year: 'numeric', month: 'short', day: 'numeric' });
}

function toInputDate(value) {
  if (!value) return '';
  const d = new Date(value);
  if (Number.isNaN(d.getTime())) return '';
  return d.toISOString().slice(0, 10);
}

function daysLeft(store) {
  if (!store.subEnd) return null;
  const diff = new Date(store.subEnd).getTime() - Date.now();
  return Math.ceil(diff / 86400000);
}

function toast(message) {
  const el = $('#toast');
  el.textContent = message;
  el.classList.add('show');
  clearTimeout(toast.timer);
  toast.timer = setTimeout(() => el.classList.remove('show'), 2600);
}

function waLink(number, text) {
  const digits = String(number || '').replace(/\D/g, '');
  const normalized = digits.startsWith('966') ? digits : digits.startsWith('0') ? '966' + digits.slice(1) : digits;
  return 'https://wa.me/' + normalized + '?text=' + encodeURIComponent(text || '');
}

async function api(path, options = {}) {
  const opts = { credentials: 'same-origin', ...options };
  opts.headers = { 'X-Requested-With': 'XMLHttpRequest', ...(opts.headers || {}) };
  if (opts.body && typeof opts.body !== 'string') {
    opts.headers = { 'Content-Type': 'application/json', ...opts.headers };
    opts.body = JSON.stringify(opts.body);
  }
  const res = await fetch(path, opts);
  const data = await res.json().catch(() => ({}));
  if (res.status === 401) {
    showLogin();
    throw new Error('انتهت الجلسة، سجّل الدخول من جديد');
  }
  if (!res.ok) throw new Error(data.error || 'حدث خطأ غير متوقع');
  return data;
}

/** طلب خروج آمن مع ترويسة CSRF. */
function logoutRequest() {
  return fetch('/api/admin/logout', {
    method: 'POST',
    credentials: 'same-origin',
    headers: { 'X-Requested-With': 'XMLHttpRequest' }
  });
}

/* --------------------------------- الدخول --------------------------------- */

function showLogin() {
  $('#adminApp').hidden = true;
  $('#loginScreen').hidden = false;
  document.getElementById('forcePasswordModal')?.remove();
  $('#password').value = '';
  $('#password').focus();
}

function showApp() {
  $('#loginScreen').hidden = true;
  $('#adminApp').hidden = false;
  resetIdleTimer();
}

async function login(password) {
  const btn = $('#loginBtn');
  const error = $('#loginError');
  btn.disabled = true;
  btn.textContent = 'جاري التحقق…';
  error.hidden = true;

  try {
    await api('/api/admin/login', { method: 'POST', body: { password } });
    showApp();
    await loadData();
  } catch (err) {
    error.textContent = err.message;
    error.hidden = false;
  } finally {
    btn.disabled = false;
    btn.textContent = 'دخول';
  }
}

async function loadData() {
  state.data = await api('/api/admin/data');
  lastPending = pendingSubmissions().length;
  render();
  if (state.data.security?.usingDefaultPassword) openForcePasswordChange();
}

/* --------------------------------- العرض ---------------------------------- */

const TITLES = {
  overview: 'نظرة عامة',
  stores: 'المحلات',
  products: 'المنتجات',
  banners: 'الإعلانات',
  orders: 'الطلبات',
  submissions: 'طلبات العملاء',
  settings: 'الإعدادات'
};

function expiringStores() {
  return state.data.stores.filter((s) => s.live && daysLeft(s) !== null && daysLeft(s) <= 14);
}

function pendingSubmissions() {
  return (state.data.submissions || []).filter((s) => s.status === 'pending');
}

function updateBadges(counts) {
  const c = counts || {};
  const orders = c.newOrders != null ? c.newOrders : state.data.orders.filter((o) => o.status === 'new').length;
  const subs = c.pendingSubmissions != null ? c.pendingSubmissions : pendingSubmissions().length;
  const stores = c.expiringStores != null ? c.expiringStores : expiringStores().length;
  [['#ordersCount', orders], ['#subsCount', subs], ['#storesCount', stores]].forEach(([sel, n]) => {
    const el = $(sel);
    if (!el) return;
    el.textContent = n;
    el.hidden = !n;
  });
}

function alertsMarkup() {
  const pending = pendingSubmissions().length;
  const expiring = expiringStores().length;
  if (!pending && !expiring) return '';
  const parts = [];
  if (pending) parts.push(`${pending} طلب من العملاء بانتظار الموافقة`);
  if (expiring) parts.push(`${expiring} اشتراك ينتهي خلال ١٤ يوماً`);
  return `
    <div class="admin-alert">
      <div class="admin-alert-text">🔔 ${parts.join(' • ')}</div>
      <div class="admin-alert-actions">
        ${pending ? `<button class="mini-btn" data-action="goto" data-tab="submissions">مراجعة الطلبات</button>` : ''}
        ${expiring ? `<button class="mini-btn" data-action="goto" data-tab="stores">عرض الاشتراكات</button>` : ''}
      </div>
    </div>`;
}

function securityAlertMarkup() {
  if (!state.data.security?.usingDefaultPassword) return '';
  return `
    <div class="admin-alert danger">
      <div class="admin-alert-text">🔒 ما زلت تستخدم الرمز الافتراضي — أي شخص يعرفه يستطيع الدخول والتحكم بالموقع. غيّره الآن.</div>
      <div class="admin-alert-actions">
        <button class="mini-btn" data-action="goto" data-tab="settings">تغيير الرمز الآن</button>
      </div>
    </div>`;
}

function render() {
  $$('.side-link[data-tab]').forEach((btn) => btn.classList.toggle('active', btn.dataset.tab === state.tab));
  $('#pageTitle').textContent = TITLES[state.tab];

  updateBadges();

  $('#topbarMeta').textContent = new Date().toLocaleDateString('ar-SA-u-ca-gregory-nu-latn', {
    weekday: 'long',
    day: 'numeric',
    month: 'long',
    year: 'numeric'
  });

  const content = $('#adminContent');
  const alert = securityAlertMarkup() + alertsMarkup();
  if (state.tab === 'overview') content.innerHTML = alert + viewOverview();
  else if (state.tab === 'stores') content.innerHTML = alert + viewStores();
  else if (state.tab === 'products') content.innerHTML = alert + viewProducts();
  else if (state.tab === 'banners') content.innerHTML = alert + viewBanners();
  else if (state.tab === 'orders') content.innerHTML = alert + viewOrders();
  else if (state.tab === 'submissions') content.innerHTML = alert + viewSubmissions();
  else content.innerHTML = alert + viewSettings();

  if (state.tab === 'settings') bindSettings();
  if (state.tab === 'orders') bindOrders();
  if (state.tab === 'submissions') bindSubmissions();
  if (state.tab === 'stores' || state.tab === 'products') bindSearch();
}

/* ------------------------------- نظرة عامة ------------------------------- */

function viewOverview() {
  const { stores, products, orders, banners } = state.data;
  const live = stores.filter((s) => s.live);
  const expiring = stores.filter((s) => s.live && daysLeft(s) !== null && daysLeft(s) <= 14);
  const newOrders = orders.filter((o) => o.status === 'new');
  const revenue = orders.filter((o) => o.status !== 'cancelled').reduce((sum, o) => sum + o.total, 0);
  const activeBanners = (banners || []).filter((b) => b.active);

  const recent = orders.slice(0, 5);

  return `
    <div class="stats">
      <div class="stat"><span class="label">محلات مشتركة</span><span class="value">${stores.length}</span><span class="hint">${live.length} ظاهرة الآن</span></div>
      <div class="stat ${expiring.length ? 'warn' : ''}"><span class="label">اشتراكات تنتهي قريباً</span><span class="value">${expiring.length}</span><span class="hint">خلال ١٤ يوماً</span></div>
      <div class="stat"><span class="label">منتجات</span><span class="value">${products.length}</span><span class="hint">${products.filter((p) => p.active).length} مفعّلة</span></div>
      <div class="stat"><span class="label">طلبات جديدة</span><span class="value">${newOrders.length}</span><span class="hint">من إجمالي ${orders.length} طلب</span></div>
      <div class="stat"><span class="label">قيمة الطلبات</span><span class="value">${money(revenue)}</span><span class="hint">ريال (بدون الملغية)</span></div>
      <div class="stat"><span class="label">إعلانات</span><span class="value">${(banners || []).length}</span><span class="hint">${activeBanners.length} ظاهر في الواجهة</span></div>
    </div>

    ${
      expiring.length
        ? `<div class="panel">
             <div class="panel-head">
               <div><h3>اشتراكات تنتهي قريباً</h3><p>${expiring.length} محل يحتاج تجديد</p></div>
             </div>
             <div class="table-wrap">
               <table class="data">
                 <thead><tr><th>المحل</th><th>ينتهي في</th><th>المتبقي</th><th></th></tr></thead>
                 <tbody>
                   ${expiring
                     .map(
                       (s) => `<tr>
                         <td><div class="cell-main">${escapeHtml(s.name)}</div></td>
                         <td>${fmtDate(s.subEnd)}</td>
                         <td><span class="pill ${daysLeft(s) <= 3 ? 'warn' : 'info'}">${daysLeft(s)} يوم</span></td>
                         <td><div class="row-actions"><button class="mini-btn" data-action="renew-store" data-id="${escapeHtml(s.id)}">تجديد</button><button class="mini-btn" data-action="edit-store" data-id="${escapeHtml(s.id)}">تعديل</button></div></td>
                       </tr>`
                     )
                     .join('')}
                 </tbody>
               </table>
             </div>
           </div>`
        : ''
    }

    <div class="panel">
      <div class="panel-head">
        <div><h3>أحدث الطلبات</h3><p>آخر ما وصل من الزبائن</p></div>
        <div class="panel-actions"><button class="mini-btn" data-action="goto" data-tab="orders">كل الطلبات</button></div>
      </div>
      ${
        recent.length
          ? `<div class="table-wrap">
               <table class="data">
                 <thead><tr><th>الطلب</th><th>الزبون</th><th>الإجمالي</th><th>الحالة</th><th>التاريخ</th></tr></thead>
                 <tbody>
                   ${recent
                     .map(
                       (o) => `<tr>
                         <td><div class="cell-main">${escapeHtml(o.number)}</div><div class="cell-sub">${o.items.length} منتج</div></td>
                         <td><div class="cell-main">${escapeHtml(o.customerName)}</div><div class="cell-sub">${escapeHtml(o.phone)}</div></td>
                         <td>${money(o.total)} ر.س</td>
                         <td><span class="pill ${STATUS[o.status]?.cls || 'off'}">${STATUS[o.status]?.label || o.status}</span></td>
                         <td>${fmtDate(o.createdAt)}</td>
                       </tr>`
                     )
                     .join('')}
                 </tbody>
               </table>
             </div>`
          : `<div class="empty-admin"><div class="big">🧾</div>لا توجد طلبات بعد</div>`
      }
    </div>

    <div class="panel">
      <div class="panel-head"><div><h3>اختصارات</h3></div></div>
      <div class="panel-body panel-actions">
        <button class="btn btn-primary btn-sm" data-action="add-store">+ إضافة محل</button>
        <button class="btn btn-ghost btn-sm" data-action="add-product">+ إضافة منتج</button>
        <button class="btn btn-ghost btn-sm" data-action="add-banner">+ إعلان جديد</button>
        <a class="btn btn-ghost btn-sm" href="/" target="_blank" rel="noopener">عرض الموقع</a>
      </div>
    </div>
  `;
}

/* --------------------------------- المحلات -------------------------------- */

function viewStores() {
  const term = state.search.trim().toLowerCase();
  const list = state.data.stores.filter((s) => !term || s.name.toLowerCase().includes(term));

  return `
    <div class="panel">
      <div class="panel-head">
        <div><h3>المحلات المشتركة</h3><p>${list.length} محل — يظهر للزوار فقط من كان اشتراكه سارياً</p></div>
        <div class="panel-actions">
          <input type="search" id="searchBox" placeholder="بحث باسم المحل…" value="${escapeHtml(state.search)}">
          <button class="btn btn-primary btn-sm" data-action="add-store">+ محل جديد</button>
        </div>
      </div>
      <div class="table-wrap">
        <table class="data">
          <thead>
            <tr><th>المحل</th><th>القسم / الحي</th><th>الاشتراك</th><th>الحالة</th><th></th></tr>
          </thead>
          <tbody>
            ${
              list.length
                ? list
                    .map((s) => {
                      const cat = state.data.categories.find((c) => c.id === s.categoryId);
                      const dist = state.data.districts.find((d) => d.id === s.districtId);
                      const left = daysLeft(s);
                      return `<tr>
                        <td>
                          <div class="cell-main">${escapeHtml(s.name)}</div>
                          <div class="cell-sub">${escapeHtml(s.phone || s.whatsapp || '')}</div>
                        </td>
                        <td><div class="cell-main" style="font-weight:600">${escapeHtml(cat?.name || '—')}</div><div class="cell-sub">${escapeHtml(dist?.name || '—')}</div></td>
                        <td>
                          <div class="cell-main" style="font-weight:600">${s.subEnd ? fmtDate(s.subEnd) : 'بدون تاريخ'}</div>
                          ${left !== null ? `<div class="cell-sub">${left >= 0 ? left + ' يوم متبقي' : 'منتهي'}</div>` : ''}
                        </td>
                        <td>
                          <div style="display:flex;gap:4px;flex-wrap:wrap">
                            ${s.live ? '<span class="pill ok">ظاهر</span>' : '<span class="pill off">مخفي</span>'}
                            ${s.featured ? '<span class="pill gold">مميز</span>' : ''}
                          </div>
                        </td>
                        <td>
                          <div class="row-actions">
                            <button class="mini-btn" data-action="renew-store" data-id="${escapeHtml(s.id)}">تجديد</button>
                            <button class="mini-btn" data-action="edit-store" data-id="${escapeHtml(s.id)}">تعديل</button>
                            <button class="mini-btn danger" data-action="del-store" data-id="${escapeHtml(s.id)}">حذف</button>
                          </div>
                        </td>
                      </tr>`;
                    })
                    .join('')
                : `<tr><td colspan="5"><div class="empty-admin"><div class="big">🏬</div>لا توجد محلات</div></td></tr>`
            }
          </tbody>
        </table>
      </div>
    </div>
  `;
}

/* -------------------------------- المنتجات -------------------------------- */

function viewProducts() {
  const term = state.search.trim().toLowerCase();
  const list = state.data.products.filter((p) => {
    if (!term) return true;
    const store = state.data.stores.find((s) => s.id === p.storeId);
    return p.name.toLowerCase().includes(term) || (store?.name || '').toLowerCase().includes(term);
  });

  return `
    <div class="panel">
      <div class="panel-head">
        <div><h3>المنتجات</h3><p>${list.length} منتج</p></div>
        <div class="panel-actions">
          <input type="search" id="searchBox" placeholder="بحث بالمنتج أو المحل…" value="${escapeHtml(state.search)}">
          <button class="btn btn-primary btn-sm" data-action="add-product">+ منتج جديد</button>
        </div>
      </div>
      <div class="table-wrap">
        <table class="data">
          <thead><tr><th>المنتج</th><th>المحل</th><th>السعر</th><th>القسم</th><th>الحالة</th><th></th></tr></thead>
          <tbody>
            ${
              list.length
                ? list
                    .map((p) => {
                      const store = state.data.stores.find((s) => s.id === p.storeId);
                      const cat = state.data.categories.find((c) => c.id === p.categoryId);
                      return `<tr>
                        <td>
                          <div class="cell-main">${escapeHtml(p.name)}</div>
                          ${p.featured ? '<div class="cell-sub">مميز في الرئيسية</div>' : ''}
                        </td>
                        <td>${escapeHtml(store?.name || '—')}</td>
                        <td><div class="cell-main" style="white-space:nowrap">${money(p.price)} ر.س</div>${p.oldPrice > p.price ? `<div class="cell-sub" style="text-decoration:line-through">${money(p.oldPrice)}</div>` : ''}</td>
                        <td>${escapeHtml(cat?.name || '—')}</td>
                        <td>${p.active ? '<span class="pill ok">معروض</span>' : '<span class="pill off">مخفي</span>'}</td>
                        <td>
                          <div class="row-actions">
                            <button class="mini-btn" data-action="quick-price" data-id="${escapeHtml(p.id)}">السعر</button>
                            <button class="mini-btn" data-action="edit-product" data-id="${escapeHtml(p.id)}">تعديل</button>
                            <button class="mini-btn danger" data-action="del-product" data-id="${escapeHtml(p.id)}">حذف</button>
                          </div>
                        </td>
                      </tr>`;
                    })
                    .join('')
                : `<tr><td colspan="6"><div class="empty-admin"><div class="big">📦</div>لا توجد منتجات</div></td></tr>`
            }
          </tbody>
        </table>
      </div>
    </div>
  `;
}

/* -------------------------------- الإعلانات -------------------------------- */

function viewBanners() {
  const list = state.data.banners || [];
  const active = list.filter((b) => b.active);

  return `
    <div class="panel">
      <div class="panel-head">
        <div><h3>شاشة الإعلانات</h3><p>${list.length} إعلان — ${active.length} ظاهر في أعلى الصفحة الرئيسية</p></div>
        <div class="panel-actions">
          <button class="btn btn-primary btn-sm" data-action="add-banner">+ إعلان جديد</button>
        </div>
      </div>
      ${
        list.length
          ? `<div class="banner-admin-grid">${list.map(bannerAdminCard).join('')}</div>`
          : `<div class="empty-admin"><div class="big">📣</div>لا توجد إعلانات بعد — أضف أول إعلان ليظهر في أعلى الصفحة الرئيسية</div>`
      }
    </div>

    <div class="panel">
      <div class="panel-head"><div><h3>كيف تعمل الإعلانات؟</h3><p>ملاحظات سريعة قبل النشر</p></div></div>
      <div class="panel-body banner-tips">
        <div>• تظهر الإعلانات في شريط متحرك أعلى الصفحة الرئيسية، بترتيب حقل «الترتيب» من الأصغر للأكبر.</div>
        <div>• الرابط يقبل مساراً داخلياً مثل <code>#/stores</code> أو <code>#/store/st_qahwa</code>، أو رابطاً خارجياً مثل واتساب.</div>
        <div>• الإعلان غير المفعّل يبقى محفوظاً في اللوحة لكنه لا يظهر للزوار.</div>
        <div>• بدون صورة خلفية يُستخدم تدرّج لوني حسب القالب، والصورة تُغطّى بطبقة داكنة لتبقى الكتابة واضحة.</div>
      </div>
    </div>
  `;
}

function bannerAdminCard(b) {
  const theme = ['emerald', 'amber', 'ink'].includes(b.theme) ? b.theme : 'emerald';
  const bg = b.image
    ? `background-image:linear-gradient(135deg,rgba(4,24,17,.82),rgba(4,24,17,.5)),url('${escapeHtml(b.image)}')`
    : '';

  return `
    <article class="banner-admin-card">
      <div class="banner-admin-preview theme-${theme}" style="${bg}">
        <span class="eyebrow-badge">إعلان</span>
        <h4>${escapeHtml(b.title)}</h4>
        ${b.subtitle ? `<p>${escapeHtml(b.subtitle)}</p>` : ''}
        ${b.cta ? `<span class="cta">${escapeHtml(b.cta)}</span>` : ''}
      </div>
      <div class="banner-admin-meta">
        <span class="pill ${b.active ? 'ok' : 'off'}">${b.active ? 'ظاهر' : 'مخفي'}</span>
        <span class="pill info">ترتيب ${Number(b.order) || 0}</span>
        ${b.link ? `<span class="banner-link" title="${escapeHtml(b.link)}" dir="ltr">${escapeHtml(b.link)}</span>` : '<span class="banner-link">بدون رابط</span>'}
      </div>
      <div class="banner-admin-actions">
        <button class="mini-btn" data-action="edit-banner" data-id="${escapeHtml(b.id)}">تعديل</button>
        <button class="mini-btn" data-action="toggle-banner" data-id="${escapeHtml(b.id)}">${b.active ? 'إخفاء' : 'إظهار'}</button>
        <button class="mini-btn danger" data-action="del-banner" data-id="${escapeHtml(b.id)}">حذف</button>
      </div>
    </article>`;
}

/* --------------------------------- الطلبات -------------------------------- */

function viewOrders() {
  const orders = state.data.orders;
  const filter = state.orderFilter || 'all';
  const list = filter === 'all' ? orders : orders.filter((o) => o.status === filter);

  return `
    <div class="panel">
      <div class="panel-head">
        <div><h3>الطلبات</h3><p>${list.length} طلب</p></div>
        <div class="panel-actions">
          <select class="chip" id="orderFilter" style="height:36px">
            <option value="all" ${filter === 'all' ? 'selected' : ''}>كل الحالات</option>
            <option value="new" ${filter === 'new' ? 'selected' : ''}>جديد</option>
            <option value="contacted" ${filter === 'contacted' ? 'selected' : ''}>تم التواصل</option>
            <option value="done" ${filter === 'done' ? 'selected' : ''}>مكتمل</option>
            <option value="cancelled" ${filter === 'cancelled' ? 'selected' : ''}>ملغي</option>
          </select>
        </div>
      </div>
      <div class="panel-body">
        ${
          list.length
            ? list
                .map((o) => {
                  const status = STATUS[o.status] || STATUS.new;
                  return `<div class="order-card">
                    <div class="order-top">
                      <div>
                        <div class="order-num">${escapeHtml(o.number)} <span class="pill ${status.cls}">${status.label}</span></div>
                        <div class="order-meta">${escapeHtml(o.customerName)} • ${escapeHtml(o.phone)} • ${fmtDate(o.createdAt)}</div>
                      </div>
                      <div class="order-total">${money(o.total)} ر.س</div>
                    </div>
                    <div class="order-items">
                      ${o.items.map((i) => `<div>• ${escapeHtml(i.name)} × ${i.qty} — ${escapeHtml(i.storeName)} (${money(i.price * i.qty)} ر.س)</div>`).join('')}
                    </div>
                    ${o.note ? `<div class="order-meta" style="margin-top:6px">📝 ${escapeHtml(o.note)}</div>` : ''}
                    <div class="order-actions">
                      <a class="mini-btn" href="${escapeHtml(waLink(o.phone, `مرحباً ${o.customerName}، بخصوص طلبك ${o.number} في سوق حفر الباطن`))}" target="_blank" rel="noopener">واتساب الزبون</a>
                      ${o.items[0]?.storeWhatsapp ? `<a class="mini-btn" href="${escapeHtml(waLink(o.items[0].storeWhatsapp, `طلب ${o.number} — ${o.customerName} — ${o.phone}`))}" target="_blank" rel="noopener">إرسال للمحل</a>` : ''}
                      <select class="mini-btn" data-order-status="${escapeHtml(o.id)}" style="height:30px">
                        ${Object.keys(STATUS).map((key) => `<option value="${key}" ${o.status === key ? 'selected' : ''}>${STATUS[key].label}</option>`).join('')}
                      </select>
                    </div>
                  </div>`;
                })
                .join('')
            : `<div class="empty-admin"><div class="big">🧾</div>لا توجد طلبات في هذه الحالة</div>`
        }
      </div>
    </div>
  `;
}

/* ----------------------------- طلبات العملاء ------------------------------ */

function viewSubmissions() {
  const all = state.data.submissions || [];
  const filter = state.subFilter || 'pending';
  const list = filter === 'all' ? all : all.filter((s) => s.status === filter);
  const pending = all.filter((s) => s.status === 'pending').length;

  return `
    <div class="panel">
      <div class="panel-head">
        <div><h3>طلبات العملاء</h3><p>${pending} بانتظار الموافقة — من إجمالي ${all.length} طلب</p></div>
        <div class="panel-actions">
          <select class="chip" id="subFilter" style="height:36px">
            <option value="pending" ${filter === 'pending' ? 'selected' : ''}>بانتظار الموافقة</option>
            <option value="approved" ${filter === 'approved' ? 'selected' : ''}>تمت الموافقة</option>
            <option value="rejected" ${filter === 'rejected' ? 'selected' : ''}>مرفوضة</option>
            <option value="all" ${filter === 'all' ? 'selected' : ''}>الكل</option>
          </select>
        </div>
      </div>
      <div class="panel-body">
        ${
          list.length
            ? `<div class="submission-list">${list.map(submissionAdminCard).join('')}</div>`
            : `<div class="empty-admin"><div class="big">📥</div>${filter === 'pending' ? 'لا توجد طلبات بانتظار الموافقة حالياً' : 'لا توجد طلبات في هذه الحالة'}</div>`
        }
      </div>
    </div>

    <div class="panel">
      <div class="panel-head"><div><h3>كيف تعمل طلبات العملاء؟</h3><p>مراجعة سريعة قبل النشر</p></div></div>
      <div class="panel-body banner-tips">
        <div>• يستطيع الزائر إرسال منتج جديد أو صورة لمنتج موجود من صفحة المحل أو من الواجهة الرئيسية.</div>
        <div>• لا يظهر أي شيء للزوار قبل موافقتك؛ الطلب يبقى «بانتظار الموافقة».</div>
        <div>• عند الموافقة على منتج جديد يُضاف مباشرة إلى منتجات المحل ويظهر في الواجهة.</div>
        <div>• عند الموافقة على صورة تُستبدل صورة المنتج الموجود بالصورة المرسلة.</div>
        <div>• عند الرفض يمكنك كتابة سبب اختياري، ويبقى الطلب محفوظاً في السجل.</div>
      </div>
    </div>
  `;
}

function submissionAdminCard(s) {
  const type = SUB_TYPE[s.type] || SUB_TYPE.product;
  const status = SUB_STATUS[s.status] || SUB_STATUS.pending;
  const store = state.data.stores.find((x) => x.id === s.storeId);

  return `
    <article class="submission-card">
      <div class="submission-thumb">
        ${s.image ? `<img src="${escapeHtml(s.image)}" alt="${escapeHtml(s.productName || s.name || '')}" loading="lazy">` : `<span>${type.icon}</span>`}
      </div>
      <div class="submission-main">
        <div class="submission-title">
          <strong>${escapeHtml(s.productName || s.name || '—')}</strong>
          <span class="pill info">${type.icon} ${type.label}</span>
          <span class="pill ${status.cls}">${status.label}</span>
        </div>
        <div class="submission-meta">
          ${escapeHtml(store?.name || s.storeName || '—')}
          ${s.price != null ? ` • ${money(s.price)} ر.س` : ''}
          • ${fmtDate(s.createdAt)}
        </div>
        <div class="submission-person">👤 ${escapeHtml(s.customerName)} • <span dir="ltr">${escapeHtml(s.phone)}</span></div>
        ${s.note ? `<div class="submission-note">📝 ${escapeHtml(s.note)}</div>` : ''}
        ${s.description ? `<div class="submission-note">${escapeHtml(s.description)}</div>` : ''}
        ${s.status === 'rejected' && s.rejectReason ? `<div class="submission-reject">سبب الرفض: ${escapeHtml(s.rejectReason)}</div>` : ''}
        ${s.status === 'approved' && s.type === 'product' ? `<div class="submission-ok">✓ نُشر المنتج في «${escapeHtml(store?.name || s.storeName || '')}»</div>` : ''}
      </div>
      <div class="submission-actions">
        ${
          s.status === 'pending'
            ? `<button class="mini-btn approve" data-action="approve-submission" data-id="${escapeHtml(s.id)}">✓ موافقة</button>
               <button class="mini-btn danger" data-action="reject-submission" data-id="${escapeHtml(s.id)}">رفض</button>`
            : `<button class="mini-btn danger" data-action="del-submission" data-id="${escapeHtml(s.id)}">حذف السجل</button>`
        }
        <a class="mini-btn" href="${escapeHtml(waLink(s.phone, `مرحباً ${s.customerName}، بخصوص طلبك في سوق حفر الباطن (${s.productName || s.name})`))}" target="_blank" rel="noopener">واتساب</a>
      </div>
    </article>`;
}

/* -------------------------------- الإعدادات ------------------------------- */

function viewSettings() {
  const s = state.data.settings;
  return `
    <div class="panel">
      <div class="panel-head"><div><h3>بيانات المنصة</h3><p>تظهر في الصفحة الرئيسية والتذييل</p></div></div>
      <div class="panel-body">
        <form id="settingsForm" class="form-grid">
          <div class="field"><label>اسم الموقع</label><input name="siteName" value="${escapeHtml(s.siteName)}" maxlength="60" required></div>
          <div class="field"><label>الجملة التعريفية</label><input name="tagline" value="${escapeHtml(s.tagline)}" maxlength="120"></div>
          <div class="field full"><label>نبذة عن المنصة</label><textarea name="about" rows="2" maxlength="400">${escapeHtml(s.about)}</textarea></div>
          <div class="field"><label>واتساب الدعم</label><input name="supportWhatsapp" value="${escapeHtml(s.supportWhatsapp)}" placeholder="9665xxxxxxxx"></div>
          <div class="field"><label>جوال الدعم</label><input name="supportPhone" value="${escapeHtml(s.supportPhone)}" placeholder="05xxxxxxxx"></div>
          <div class="full"><button class="btn btn-primary" type="submit">حفظ التعديلات</button></div>
        </form>
      </div>
    </div>

    <div class="panel">
      <div class="panel-head"><div><h3>الهوية البصرية</h3><p>الألوان والشعار يظهران للزوار في الموقع</p></div></div>
      <div class="panel-body">
        <form id="designForm" class="form-grid">
          <div class="field">
            <label>اللون الأساسي</label>
            <div class="color-field">
              <input type="color" name="primaryColor" id="primaryColor" value="${escapeHtml(s.primaryColor)}">
              <span class="color-hex" id="primaryHex" dir="ltr">${escapeHtml(s.primaryColor)}</span>
            </div>
          </div>
          <div class="field">
            <label>لون التمييز</label>
            <div class="color-field">
              <input type="color" name="accentColor" id="accentColor" value="${escapeHtml(s.accentColor)}">
              <span class="color-hex" id="accentHex" dir="ltr">${escapeHtml(s.accentColor)}</span>
            </div>
          </div>

          <div class="full theme-presets">
            <span class="presets-label">قوالب جاهزة:</span>
            ${THEME_PRESETS.map(
              (p) => `<button type="button" class="preset" data-primary="${p.primary}" data-accent="${p.accent}">
                <span class="swatch" style="background:${p.primary}"></span>
                <span class="swatch" style="background:${p.accent}"></span>
                ${p.name}
              </button>`
            ).join('')}
          </div>

          <div class="full">${imageField('logo', 'شعار الموقع (اختياري)', s.logo)}</div>

          <div class="full">
            <div class="theme-preview" id="themePreview" style="--tp-primary:${escapeHtml(s.primaryColor)};--tp-accent:${escapeHtml(s.accentColor)}">
              <div class="tp-top">
                <span class="tp-logo">${s.logo ? `<img src="${escapeHtml(s.logo)}" alt="">` : 'ح'}</span>
                <div><strong>${escapeHtml(s.siteName)}</strong><small>${escapeHtml(s.tagline)}</small></div>
              </div>
              <div class="tp-row">
                <span class="tp-btn">تسوق الآن</span>
                <span class="tp-chip">عطور</span>
                <span class="tp-dot"></span>
              </div>
            </div>
            <p class="field-hint">معاينة تقريبية — يفضّل لون أساسي غامق ليبقى النص الأبيض واضحاً على الأزرار.</p>
          </div>

          <div class="full"><button class="btn btn-primary" type="submit">حفظ الهوية</button></div>
        </form>
      </div>
    </div>

    <div class="panel">
      <div class="panel-head">
        <div><h3>الأقسام والأيقونات</h3><p>${state.data.categories.length} قسم — لكل قسم صورة أيقونة أو رمز تعبيري</p></div>
        <div class="panel-actions">
          <button class="btn btn-primary btn-sm" data-action="add-category">+ قسم جديد</button>
        </div>
      </div>
      <div class="panel-body">
        ${
          state.data.categories.length
            ? `<div class="cat-admin-grid">${state.data.categories.map(catAdminCard).join('')}</div>`
            : `<div class="empty-admin"><div class="big">🏷️</div>لا توجد أقسام — أضف أول قسم</div>`
        }
      </div>
    </div>

    <div class="panel">
      <div class="panel-head"><div><h3>تغيير الرمز السري</h3><p>استخدم رمزاً قوياً لا يقل عن ٦ أحرف</p></div></div>
      <div class="panel-body">
        <form id="passwordForm" class="form-grid">
          <div class="field"><label>الرمز الجديد</label><input type="password" name="password" minlength="8" required autocomplete="new-password" placeholder="٨ أحرف على الأقل"></div>
          <div class="field"><label>تأكيد الرمز</label><input type="password" name="confirm" minlength="8" required autocomplete="new-password"></div>
          <div class="full field-hint">عند تغيير الرمز تُلغى الجلسات المفتوحة على الأجهزة الأخرى تلقائياً. وتُقفل اللوحة بعد ساعة من عدم النشاط.</div>
          <div class="full"><button class="btn btn-primary" type="submit">تحديث الرمز</button></div>
        </form>
      </div>
    </div>
  `;
}

function catAdminCard(c) {
  return `
    <div class="cat-admin-card">
      <div class="cat-admin-icon">${c.image ? `<img src="${escapeHtml(c.image)}" alt="${escapeHtml(c.name)}">` : escapeHtml(c.icon || '📦')}</div>
      <div class="cat-admin-info">
        <strong>${escapeHtml(c.name)}</strong>
        <span>${c.image ? 'أيقونة صورة' : 'رمز تعبيري'}</span>
      </div>
      <div class="cat-admin-actions">
        <button class="mini-btn" data-action="edit-category" data-id="${escapeHtml(c.id)}">تعديل</button>
        <button class="mini-btn danger" data-action="del-category" data-id="${escapeHtml(c.id)}">حذف</button>
      </div>
    </div>`;
}

/* -------------------------------- المودال --------------------------------- */

function openModal(title, bodyHtml, footerHtml) {
  closeModal();
  const wrap = document.createElement('div');
  wrap.className = 'admin-modal';
  wrap.id = 'adminModal';
  wrap.innerHTML = `
    <div class="card">
      <header>
        <h3>${escapeHtml(title)}</h3>
        <button class="icon-btn" data-action="close-modal" aria-label="إغلاق">✕</button>
      </header>
      <div class="body">${bodyHtml}</div>
      ${footerHtml ? `<footer>${footerHtml}</footer>` : ''}
    </div>`;
  document.body.appendChild(wrap);
  document.body.classList.add('modal-open');
  wrap.addEventListener('click', (e) => {
    if (e.target === wrap) closeModal();
  });
  return wrap;
}

function closeModal() {
  document.getElementById('adminModal')?.remove();
  document.body.classList.remove('modal-open');
}

/** نافذة إلزامية عند استخدام الرمز الافتراضي — لا تُغلق حتى يتم التغيير. */
function openForcePasswordChange() {
  if (document.getElementById('forcePasswordModal')) return;
  const wrap = document.createElement('div');
  wrap.className = 'admin-modal';
  wrap.id = 'forcePasswordModal';
  wrap.innerHTML = `
    <div class="card">
      <header><h3>🔒 غيّر الرمز الافتراضي للمتابعة</h3></header>
      <div class="body">
        <p class="field-hint" style="margin-bottom:14px">
          الرمز الحالي <b>admin1234</b> معروف للجميع، وأي شخص يعرفه يستطيع الدخول والتحكم بالموقع.
          اختر رمزاً جديداً (٨ أحرف على الأقل) لحماية اللوحة.
        </p>
        <form id="forcePassForm" class="form-grid">
          <div class="field full"><label>الرمز الجديد</label><input type="password" name="password" minlength="8" required autocomplete="new-password" autofocus></div>
          <div class="field full"><label>تأكيد الرمز</label><input type="password" name="confirm" minlength="8" required autocomplete="new-password"></div>
          <p class="login-error full" id="forcePassError" hidden></p>
          <div class="full"><button class="btn btn-primary btn-block" type="submit">حفظ ومتابعة</button></div>
        </form>
      </div>
    </div>`;
  document.body.appendChild(wrap);

  const form = wrap.querySelector('#forcePassForm');
  const error = wrap.querySelector('#forcePassError');

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const data = Object.fromEntries(new FormData(form).entries());
    error.hidden = true;
    if (data.password !== data.confirm) {
      error.textContent = 'الرمزين غير متطابقين';
      error.hidden = false;
      return;
    }
    const btn = form.querySelector('button[type="submit"]');
    btn.disabled = true;
    btn.textContent = 'جاري الحفظ…';
    try {
      await api('/api/admin/password', { method: 'POST', body: { password: data.password } });
      wrap.remove();
      toast('تم تحديث الرمز — اللوحة محمية الآن');
      await loadData();
    } catch (err) {
      error.textContent = err.message;
      error.hidden = false;
      btn.disabled = false;
      btn.textContent = 'حفظ ومتابعة';
    }
  });
}

function imageField(name, label, value) {
  return `<div class="field">
    <label>${escapeHtml(label)}</label>
    <div class="image-field">
      <div class="image-preview" id="prev-${name}">${value ? `<img src="${escapeHtml(value)}" alt="">` : '🖼️'}</div>
      <input type="text" name="${name}" value="${escapeHtml(value || '')}" placeholder="رابط الصورة أو ارفع من جهازك" data-img="${name}" dir="ltr" style="text-align:left">
      <label class="btn btn-ghost btn-sm upload-btn">رفع
        <input type="file" accept="image/png,image/jpeg,image/webp" data-upload="${name}">
      </label>
    </div>
  </div>`;
}

function bindImageUploads(root) {
  $$('[data-upload]', root).forEach((input) => {
    input.addEventListener('change', async () => {
      const file = input.files?.[0];
      if (!file) return;
      if (file.size > 4 * 1024 * 1024) return toast('حجم الصورة أكبر من ٤ ميجا');

      const name = input.dataset.upload;
      const textInput = root.querySelector(`[data-img="${name}"]`);
      const preview = root.querySelector('#prev-' + name);

      try {
        const dataUrl = await new Promise((resolve, reject) => {
          const reader = new FileReader();
          reader.onload = () => resolve(reader.result);
          reader.onerror = reject;
          reader.readAsDataURL(file);
        });
        preview.innerHTML = '<span style="font-size:11px">…</span>';
        const res = await api('/api/admin/upload', { method: 'POST', body: { data: dataUrl } });
        textInput.value = res.url;
        preview.innerHTML = `<img src="${escapeHtml(res.url)}" alt="">`;
        toast('تم رفع الصورة');
      } catch (err) {
        preview.innerHTML = '🖼️';
        toast(err.message);
      }
    });
  });
}

/* ------------------------------ نموذج المحل ------------------------------- */

function openStoreForm(store) {
  const isNew = !store;
  const s = store || {
    name: '',
    categoryId: state.data.categories[0]?.id || '',
    districtId: state.data.districts[0]?.id || '',
    description: '',
    phone: '',
    whatsapp: '',
    mapsUrl: '',
    logo: '',
    cover: '',
    active: true,
    featured: false,
    subStart: new Date().toISOString(),
    subEnd: ''
  };

  const body = `
    <form id="storeForm" class="form-grid">
      <input type="hidden" name="id" value="${escapeHtml(s.id || '')}">
      <div class="field full"><label>اسم المحل *</label><input name="name" value="${escapeHtml(s.name)}" required maxlength="80"></div>

      <div class="field">
        <label>القسم</label>
        <select name="categoryId">
          ${state.data.categories.map((c) => `<option value="${escapeHtml(c.id)}" ${c.id === s.categoryId ? 'selected' : ''}>${escapeHtml(c.name)}</option>`).join('')}
        </select>
      </div>

      <div class="field">
        <label>الحي</label>
        <select name="districtId">
          ${state.data.districts.map((d) => `<option value="${escapeHtml(d.id)}" ${d.id === s.districtId ? 'selected' : ''}>${escapeHtml(d.name)}</option>`).join('')}
        </select>
      </div>

      <div class="field full"><label>وصف قصير</label><textarea name="description" rows="2" maxlength="500">${escapeHtml(s.description || '')}</textarea></div>

      <div class="field"><label>جوال المحل</label><input name="phone" value="${escapeHtml(s.phone || '')}" placeholder="05xxxxxxxx" maxlength="30" dir="ltr" style="text-align:left"></div>
      <div class="field"><label>واتساب (بصيغة دولية)</label><input name="whatsapp" value="${escapeHtml(s.whatsapp || '')}" placeholder="9665xxxxxxxx" maxlength="20" dir="ltr" style="text-align:left"></div>

      <div class="field full"><label>رابط الموقع على الخريطة</label><input name="mapsUrl" value="${escapeHtml(s.mapsUrl || '')}" placeholder="https://maps.google.com/..." dir="ltr" style="text-align:left"></div>

      <div class="full">${imageField('logo', 'شعار المحل', s.logo)}</div>
      <div class="full">${imageField('cover', 'صورة الغلاف', s.cover)}</div>

      <div class="field"><label>بداية الاشتراك</label><input type="date" name="subStart" value="${toInputDate(s.subStart)}"></div>
      <div class="field"><label>نهاية الاشتراك</label><input type="date" name="subEnd" value="${toInputDate(s.subEnd)}"></div>

      <div class="full check-row">
        <label class="check"><input type="checkbox" name="active" ${s.active ? 'checked' : ''}> مفعّل (يظهر للزوار)</label>
        <label class="check"><input type="checkbox" name="featured" ${s.featured ? 'checked' : ''}> محل مميز في الرئيسية</label>
      </div>
    </form>`;

  const footer = `
    <button class="btn btn-primary" type="submit" form="storeForm">${isNew ? 'إضافة المحل' : 'حفظ التعديلات'}</button>
    <button class="btn btn-ghost" data-action="close-modal" type="button">إلغاء</button>
  `;

  const modal = openModal(isNew ? 'محل جديد' : 'تعديل المحل', body, footer);
  bindImageUploads(modal);

  $('#storeForm', modal).addEventListener('submit', async (e) => {
    e.preventDefault();
    const form = e.target;
    const btn = modal.querySelector('button[type="submit"]');
    btn.disabled = true;
    btn.textContent = 'جاري الحفظ…';

    const payload = {
      id: form.elements.namedItem('id').value || undefined,
      name: form.elements.namedItem('name').value,
      categoryId: form.elements.namedItem('categoryId').value,
      districtId: form.elements.namedItem('districtId').value,
      description: form.elements.namedItem('description').value,
      phone: form.elements.namedItem('phone').value,
      whatsapp: form.elements.namedItem('whatsapp').value,
      mapsUrl: form.elements.namedItem('mapsUrl').value,
      logo: form.elements.namedItem('logo').value,
      cover: form.elements.namedItem('cover').value,
      subStart: form.elements.namedItem('subStart').value
        ? new Date(form.elements.namedItem('subStart').value + 'T00:00:00').toISOString()
        : new Date().toISOString(),
      subEnd: form.elements.namedItem('subEnd').value
        ? new Date(form.elements.namedItem('subEnd').value + 'T23:59:59').toISOString()
        : '',
      active: form.elements.namedItem('active').checked,
      featured: form.elements.namedItem('featured').checked
    };

    try {
      await api('/api/admin/store', { method: 'POST', body: payload });
      closeModal();
      toast('تم حفظ المحل');
      await loadData();
    } catch (err) {
      btn.disabled = false;
      btn.textContent = isNew ? 'إضافة المحل' : 'حفظ التعديلات';
      toast(err.message);
    }
  });
}

/* ------------------------------ نموذج المنتج ------------------------------ */

function openProductForm(product) {
  const isNew = !product;
  const p = product || {
    name: '',
    storeId: state.data.stores[0]?.id || '',
    categoryId: state.data.categories[0]?.id || '',
    price: '',
    oldPrice: '',
    description: '',
    image: '',
    active: true,
    featured: false
  };

  const body = `
    <form id="productForm" class="form-grid">
      <input type="hidden" name="id" value="${escapeHtml(p.id || '')}">
      <div class="field full"><label>اسم المنتج *</label><input name="name" value="${escapeHtml(p.name)}" required maxlength="120"></div>

      <div class="field">
        <label>المحل *</label>
        <select name="storeId" required>
          ${state.data.stores.map((s) => `<option value="${escapeHtml(s.id)}" ${s.id === p.storeId ? 'selected' : ''}>${escapeHtml(s.name)}</option>`).join('')}
        </select>
      </div>

      <div class="field">
        <label>القسم</label>
        <select name="categoryId">
          ${state.data.categories.map((c) => `<option value="${escapeHtml(c.id)}" ${c.id === p.categoryId ? 'selected' : ''}>${escapeHtml(c.name)}</option>`).join('')}
        </select>
      </div>

      <div class="field"><label>السعر (ر.س) *</label><input name="price" type="number" step="0.01" min="0" value="${escapeHtml(p.price)}" required></div>
      <div class="field"><label>السعر قبل الخصم (اختياري)</label><input name="oldPrice" type="number" step="0.01" min="0" value="${escapeHtml(p.oldPrice || '')}"></div>

      <div class="field full"><label>وصف المنتج</label><textarea name="description" rows="2" maxlength="500">${escapeHtml(p.description || '')}</textarea></div>

      <div class="full">${imageField('image', 'صورة المنتج', p.image)}</div>

      <div class="full check-row">
        <label class="check"><input type="checkbox" name="active" ${p.active ? 'checked' : ''}> معروض للزوار</label>
        <label class="check"><input type="checkbox" name="featured" ${p.featured ? 'checked' : ''}> منتج مميز في الرئيسية</label>
      </div>
    </form>`;

  const footer = `
    <button class="btn btn-primary" type="submit" form="productForm">${isNew ? 'إضافة المنتج' : 'حفظ التعديلات'}</button>
    <button class="btn btn-ghost" data-action="close-modal" type="button">إلغاء</button>
  `;

  const modal = openModal(isNew ? 'منتج جديد' : 'تعديل المنتج', body, footer);
  bindImageUploads(modal);

  $('#productForm', modal).addEventListener('submit', async (e) => {
    e.preventDefault();
    const form = e.target;
    const btn = modal.querySelector('button[type="submit"]');
    btn.disabled = true;
    btn.textContent = 'جاري الحفظ…';

    const payload = {
      id: form.elements.namedItem('id').value || undefined,
      name: form.elements.namedItem('name').value,
      storeId: form.elements.namedItem('storeId').value,
      categoryId: form.elements.namedItem('categoryId').value,
      price: form.elements.namedItem('price').value,
      oldPrice: form.elements.namedItem('oldPrice').value,
      description: form.elements.namedItem('description').value,
      image: form.elements.namedItem('image').value,
      active: form.elements.namedItem('active').checked,
      featured: form.elements.namedItem('featured').checked
    };

    try {
      await api('/api/admin/product', { method: 'POST', body: payload });
      closeModal();
      toast('تم حفظ المنتج');
      await loadData();
    } catch (err) {
      btn.disabled = false;
      btn.textContent = isNew ? 'إضافة المنتج' : 'حفظ التعديلات';
      toast(err.message);
    }
  });
}

/* ------------------------------ تجديد الاشتراك ----------------------------- */

function addMonths(date, months) {
  const d = new Date(date);
  const day = d.getDate();
  d.setDate(1);
  d.setMonth(d.getMonth() + months);
  const lastDay = new Date(d.getFullYear(), d.getMonth() + 1, 0).getDate();
  d.setDate(Math.min(day, lastDay));
  return d;
}

function openRenewForm(store) {
  if (!store) return;
  const left = daysLeft(store);
  const body = `
    <form id="renewForm" class="form-grid">
      <div class="full renew-summary">
        <strong>${escapeHtml(store.name)}</strong>
        <span>ينتهي حالياً في ${store.subEnd ? fmtDate(store.subEnd) : 'بدون تاريخ'}${left !== null ? ` • ${left >= 0 ? left + ' يوم متبقي' : 'منتهي'}` : ''}</span>
      </div>
      <div class="field full">
        <label>مدة التجديد</label>
        <select name="months">
          <option value="1">شهر واحد</option>
          <option value="3">٣ أشهر</option>
          <option value="6">٦ أشهر</option>
          <option value="12" selected>سنة كاملة</option>
          <option value="24">سنتان</option>
        </select>
      </div>
      <div class="full field-hint" id="renewPreview"></div>
      <div class="full field-hint">يبدأ التمديد من تاريخ الانتهاء الحالي، أو من اليوم إذا كان الاشتراك منتهياً. سيتم تفعيل المحل تلقائياً.</div>
    </form>`;

  const footer = `
    <button class="btn btn-primary" type="submit" form="renewForm">تجديد الاشتراك</button>
    <button class="btn btn-ghost" data-action="close-modal" type="button">إلغاء</button>`;

  const modal = openModal('تجديد اشتراك', body, footer);
  const form = $('#renewForm', modal);
  const preview = $('#renewPreview', modal);
  const base = new Date(Math.max(Date.now(), store.subEnd ? new Date(store.subEnd).getTime() : 0));

  const refresh = () => {
    const months = Number(form.elements.namedItem('months').value) || 12;
    const end = addMonths(base, months);
    preview.textContent = `ينتهي الاشتراك الجديد في ${fmtDate(end.toISOString())}`;
  };
  form.elements.namedItem('months').addEventListener('change', refresh);
  refresh();

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const btn = modal.querySelector('button[type="submit"]');
    btn.disabled = true;
    btn.textContent = 'جاري التجديد…';
    try {
      await api('/api/admin/store/' + store.id + '/renew', {
        method: 'POST',
        body: { months: Number(form.elements.namedItem('months').value) }
      });
      closeModal();
      toast('تم تجديد الاشتراك');
      await loadData();
    } catch (err) {
      btn.disabled = false;
      btn.textContent = 'تجديد الاشتراك';
      toast(err.message);
    }
  });
}

/* ---------------------------- تعديل سعر سريع ------------------------------ */

function openPriceForm(product) {
  if (!product) return;
  const store = state.data.stores.find((s) => s.id === product.storeId);
  const body = `
    <form id="priceForm" class="form-grid">
      <div class="full renew-summary">
        <strong>${escapeHtml(product.name)}</strong>
        <span>${escapeHtml(store?.name || '')}</span>
      </div>
      <div class="field"><label>السعر (ر.س) *</label><input name="price" type="number" step="0.01" min="0" value="${escapeHtml(product.price)}" required autofocus></div>
      <div class="field"><label>السعر قبل الخصم</label><input name="oldPrice" type="number" step="0.01" min="0" value="${escapeHtml(product.oldPrice || '')}"></div>
      <div class="full field-hint">اترك «السعر قبل الخصم» فارغاً أو صفراً إذا لم يوجد خصم.</div>
    </form>`;

  const footer = `
    <button class="btn btn-primary" type="submit" form="priceForm">حفظ السعر</button>
    <button class="btn btn-ghost" data-action="close-modal" type="button">إلغاء</button>`;

  const modal = openModal('تعديل السعر', body, footer);
  const form = $('#priceForm', modal);

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const btn = modal.querySelector('button[type="submit"]');
    btn.disabled = true;
    btn.textContent = 'جاري الحفظ…';
    try {
      await api('/api/admin/product', {
        method: 'POST',
        body: {
          ...product,
          price: form.elements.namedItem('price').value,
          oldPrice: form.elements.namedItem('oldPrice').value
        }
      });
      closeModal();
      toast('تم تحديث السعر');
      await loadData();
    } catch (err) {
      btn.disabled = false;
      btn.textContent = 'حفظ السعر';
      toast(err.message);
    }
  });
}

/* ------------------------------ رفض طلب عميل ------------------------------ */

function openRejectForm(sub) {
  if (!sub) return;
  const body = `
    <form id="rejectForm" class="form-grid">
      <div class="full renew-summary">
        <strong>${escapeHtml(sub.productName || sub.name || '—')}</strong>
        <span>${escapeHtml(sub.storeName || '')} • ${escapeHtml(sub.customerName)}</span>
      </div>
      <div class="field full">
        <label>سبب الرفض (اختياري)</label>
        <textarea name="reason" rows="3" maxlength="300" placeholder="مثال: الصورة غير واضحة أو السعر غير مكتمل"></textarea>
      </div>
      <div class="full field-hint">لن يُنشر الطلب، وسيبقى محفوظاً في سجل الطلبات المرفوضة.</div>
    </form>`;

  const footer = `
    <button class="btn btn-danger" type="submit" form="rejectForm">تأكيد الرفض</button>
    <button class="btn btn-ghost" data-action="close-modal" type="button">إلغاء</button>`;

  const modal = openModal('رفض الطلب', body, footer);
  const form = $('#rejectForm', modal);

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const btn = modal.querySelector('button[type="submit"]');
    btn.disabled = true;
    btn.textContent = 'جاري الرفض…';
    try {
      await api('/api/admin/submission/' + sub.id + '/reject', {
        method: 'POST',
        body: { reason: form.elements.namedItem('reason').value }
      });
      closeModal();
      toast('تم رفض الطلب');
      await loadData();
    } catch (err) {
      btn.disabled = false;
      btn.textContent = 'تأكيد الرفض';
      toast(err.message);
    }
  });
}

/* ------------------------------ نموذج الإعلان ------------------------------ */

function openBannerForm(banner) {
  const isNew = !banner;
  const b = banner || {
    title: '',
    subtitle: '',
    cta: '',
    link: '',
    image: '',
    theme: 'emerald',
    active: true,
    order: (state.data.banners?.length || 0) + 1
  };

  const body = `
    <form id="bannerForm" class="form-grid">
      <input type="hidden" name="id" value="${escapeHtml(b.id || '')}">

      <div class="field full">
        <label>عنوان الإعلان *</label>
        <input name="title" value="${escapeHtml(b.title)}" required maxlength="80" placeholder="مثال: عروض نهاية الأسبوع">
      </div>

      <div class="field full">
        <label>الوصف المختصر</label>
        <textarea name="subtitle" rows="2" maxlength="180" placeholder="سطر أو سطرين يوضحان العرض">${escapeHtml(b.subtitle || '')}</textarea>
      </div>

      <div class="field"><label>نص الزر</label><input name="cta" value="${escapeHtml(b.cta || '')}" maxlength="30" placeholder="تسوق العروض"></div>
      <div class="field"><label>الترتيب</label><input name="order" type="number" min="0" step="1" value="${Number(b.order) || 0}"></div>

      <div class="field full">
        <label>الرابط</label>
        <input name="link" value="${escapeHtml(b.link || '')}" maxlength="500" placeholder="#/stores أو https://wa.me/..." dir="ltr" style="text-align:left">
      </div>

      <div class="field">
        <label>القالب اللوني</label>
        <select name="theme">
          <option value="emerald" ${b.theme === 'emerald' ? 'selected' : ''}>أخضر (الأساسي)</option>
          <option value="amber" ${b.theme === 'amber' ? 'selected' : ''}>ذهبي</option>
          <option value="ink" ${b.theme === 'ink' ? 'selected' : ''}>داكن</option>
        </select>
      </div>

      <div class="field" style="display:flex;align-items:flex-end">
        <label class="check" style="margin-bottom:11px"><input type="checkbox" name="active" ${b.active ? 'checked' : ''}> ظاهر في الصفحة الرئيسية</label>
      </div>

      <div class="full">${imageField('image', 'صورة الخلفية (اختياري)', b.image)}</div>
    </form>`;

  const footer = `
    <button class="btn btn-primary" type="submit" form="bannerForm">${isNew ? 'إضافة الإعلان' : 'حفظ التعديلات'}</button>
    <button class="btn btn-ghost" data-action="close-modal" type="button">إلغاء</button>
  `;

  const modal = openModal(isNew ? 'إعلان جديد' : 'تعديل الإعلان', body, footer);
  bindImageUploads(modal);

  $('#bannerForm', modal).addEventListener('submit', async (e) => {
    e.preventDefault();
    const form = e.target;
    const btn = modal.querySelector('button[type="submit"]');
    btn.disabled = true;
    btn.textContent = 'جاري الحفظ…';

    const payload = {
      id: form.elements.namedItem('id').value || undefined,
      title: form.elements.namedItem('title').value,
      subtitle: form.elements.namedItem('subtitle').value,
      cta: form.elements.namedItem('cta').value,
      link: form.elements.namedItem('link').value,
      image: form.elements.namedItem('image').value,
      theme: form.elements.namedItem('theme').value,
      order: form.elements.namedItem('order').value,
      active: form.elements.namedItem('active').checked
    };

    try {
      await api('/api/admin/banner', { method: 'POST', body: payload });
      closeModal();
      toast('تم حفظ الإعلان');
      await loadData();
    } catch (err) {
      btn.disabled = false;
      btn.textContent = isNew ? 'إضافة الإعلان' : 'حفظ التعديلات';
      toast(err.message);
    }
  });
}

/* ------------------------------ نموذج القسم ------------------------------- */

function openCategoryForm(category) {
  const isNew = !category;
  const c = category || { name: '', icon: '📦', image: '' };

  const body = `
    <form id="categoryForm" class="form-grid">
      <input type="hidden" name="id" value="${escapeHtml(c.id || '')}">

      <div class="field full">
        <label>اسم القسم *</label>
        <input name="name" value="${escapeHtml(c.name)}" required maxlength="40" placeholder="مثال: ألعاب">
      </div>

      <div class="field">
        <label>رمز تعبيري (بديل)</label>
        <input name="icon" value="${escapeHtml(c.icon || '📦')}" maxlength="8" placeholder="📦">
      </div>

      <div class="field" style="display:flex;align-items:flex-end">
        <p style="font-size:11.5px;color:var(--muted);line-height:1.7;margin-bottom:7px">
          الرمز يظهر إذا لم ترفع صورة، ويُستخدم كأيقونة افتراضية لمنتجات القسم.
        </p>
      </div>

      <div class="full">${imageField('image', 'صورة الأيقونة', c.image)}</div>

      <div class="full" style="font-size:11.5px;color:var(--muted);line-height:1.7">
        يفضّل صورة مربعة (٢٠٠×٢٠٠) بخلفية بسيطة أو شفافة. امسح حقل الصورة لإزالتها والعودة للرمز التعبيري.
      </div>
    </form>`;

  const footer = `
    <button class="btn btn-primary" type="submit" form="categoryForm">${isNew ? 'إضافة القسم' : 'حفظ التعديلات'}</button>
    <button class="btn btn-ghost" data-action="close-modal" type="button">إلغاء</button>
  `;

  const modal = openModal(isNew ? 'قسم جديد' : 'تعديل القسم', body, footer);
  bindImageUploads(modal);

  $('#categoryForm', modal).addEventListener('submit', async (e) => {
    e.preventDefault();
    const form = e.target;
    const btn = modal.querySelector('button[type="submit"]');
    btn.disabled = true;
    btn.textContent = 'جاري الحفظ…';

    const payload = {
      id: form.elements.namedItem('id').value || undefined,
      name: form.elements.namedItem('name').value,
      icon: form.elements.namedItem('icon').value,
      image: form.elements.namedItem('image').value
    };

    try {
      await api('/api/admin/category', { method: 'POST', body: payload });
      closeModal();
      toast(isNew ? 'تمت إضافة القسم' : 'تم حفظ القسم');
      await loadData();
    } catch (err) {
      btn.disabled = false;
      btn.textContent = isNew ? 'إضافة القسم' : 'حفظ التعديلات';
      toast(err.message);
    }
  });
}

/* -------------------------------- الأحداث --------------------------------- */

function bindSearch() {
  const box = $('#searchBox');
  if (!box) return;
  let timer;
  box.addEventListener('input', () => {
    clearTimeout(timer);
    timer = setTimeout(() => {
      state.search = box.value;
      const active = document.activeElement === box;
      render();
      if (active) {
        const next = $('#searchBox');
        next.focus();
        next.setSelectionRange(next.value.length, next.value.length);
      }
    }, 220);
  });
}

function bindOrders() {
  const filter = $('#orderFilter');
  filter?.addEventListener('change', () => {
    state.orderFilter = filter.value;
    render();
  });

  $$('[data-order-status]').forEach((select) => {
    select.addEventListener('change', async () => {
      try {
        await api('/api/admin/order/' + select.dataset.orderStatus + '/status', {
          method: 'POST',
          body: { status: select.value }
        });
        toast('تم تحديث حالة الطلب');
        await loadData();
      } catch (err) {
        toast(err.message);
      }
    });
  });
}

function bindSubmissions() {
  const filter = $('#subFilter');
  filter?.addEventListener('change', () => {
    state.subFilter = filter.value;
    render();
  });
}

function updateDesignPreview() {
  const primary = $('#primaryColor');
  const accent = $('#accentColor');
  const preview = $('#themePreview');
  if (!primary || !accent || !preview) return;

  preview.style.setProperty('--tp-primary', primary.value);
  preview.style.setProperty('--tp-accent', accent.value);
  const primaryHex = $('#primaryHex');
  const accentHex = $('#accentHex');
  if (primaryHex) primaryHex.textContent = primary.value;
  if (accentHex) accentHex.textContent = accent.value;

  const logoInput = $('#designForm input[name="logo"]');
  const tpLogo = preview.querySelector('.tp-logo');
  if (tpLogo) {
    tpLogo.textContent = '';
    if (logoInput?.value) {
      const img = document.createElement('img');
      img.src = logoInput.value;
      img.alt = '';
      tpLogo.appendChild(img);
    } else {
      tpLogo.textContent = 'ح';
    }
  }
}

function bindSettings() {
  const form = $('#settingsForm');
  form?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const data = Object.fromEntries(new FormData(form).entries());
    try {
      await api('/api/admin/settings', { method: 'POST', body: data });
      toast('تم حفظ الإعدادات');
      await loadData();
    } catch (err) {
      toast(err.message);
    }
  });

  const design = $('#designForm');
  if (design) {
    bindImageUploads(design);
    ['#primaryColor', '#accentColor'].forEach((sel) => $(sel)?.addEventListener('input', updateDesignPreview));
    design.elements.namedItem('logo')?.addEventListener('input', updateDesignPreview);

    $$('.preset', design).forEach((btn) => {
      btn.addEventListener('click', () => {
        $('#primaryColor').value = btn.dataset.primary;
        $('#accentColor').value = btn.dataset.accent;
        updateDesignPreview();
      });
    });

    design.addEventListener('submit', async (e) => {
      e.preventDefault();
      const data = Object.fromEntries(new FormData(design).entries());
      try {
        await api('/api/admin/settings', { method: 'POST', body: data });
        toast('تم حفظ الهوية البصرية');
        await loadData();
      } catch (err) {
        toast(err.message);
      }
    });

    updateDesignPreview();
  }

  const passForm = $('#passwordForm');
  passForm?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const data = Object.fromEntries(new FormData(passForm).entries());
    if (data.password !== data.confirm) return toast('الرمزين غير متطابقين');
    try {
      await api('/api/admin/password', { method: 'POST', body: { password: data.password } });
      passForm.reset();
      toast('تم تحديث الرمز السري');
    } catch (err) {
      toast(err.message);
    }
  });
}

/* --------------------------------- التشغيل -------------------------------- */

/* ------------------------- قفل تلقائي عند عدم النشاط ------------------------ */

const IDLE_LIMIT_MS = 60 * 60 * 1000;
let idleTimer = null;

function resetIdleTimer() {
  clearTimeout(idleTimer);
  if (!$('#adminApp') || $('#adminApp').hidden) return;
  idleTimer = setTimeout(lockAdmin, IDLE_LIMIT_MS);
}

async function lockAdmin() {
  try {
    await logoutRequest();
  } catch (err) {
    /* حتى لو فشل الطلب نُخفي الواجهة */
  }
  showLogin();
  toast('تم قفل اللوحة تلقائياً بسبب عدم النشاط');
}

['mousemove', 'keydown', 'click', 'scroll', 'touchstart'].forEach((ev) => {
  document.addEventListener(ev, resetIdleTimer, { passive: true });
});

async function pollNotifications() {
  if (document.hidden || $('#adminApp').hidden) return;
  try {
    const counts = await api('/api/admin/notifications');
    updateBadges(counts);
    if (lastPending !== null && counts.pendingSubmissions > lastPending) {
      toast('🔔 وصل طلب جديد من عميل بانتظار الموافقة');
    }
    lastPending = counts.pendingSubmissions;
  } catch (err) {
    /* تجاهل أخطاء الشبكة المؤقتة */
  }
}

setInterval(pollNotifications, 30000);
document.addEventListener('visibilitychange', () => {
  if (!document.hidden) pollNotifications();
});

async function boot() {
  try {
    const res = await fetch('/api/admin/session', { credentials: 'same-origin' });
    const data = await res.json();
    if (data.authenticated) {
      showApp();
      await loadData();
    } else {
      showLogin();
    }
  } catch (err) {
    showLogin();
  }
}

$('#loginForm').addEventListener('submit', (e) => {
  e.preventDefault();
  login($('#password').value);
});

$('#logoutBtn').addEventListener('click', async () => {
  clearTimeout(idleTimer);
  await logoutRequest();
  showLogin();
  toast('تم تسجيل الخروج');
});

$('#sideNav').addEventListener('click', async (e) => {
  const btn = e.target.closest('[data-tab]');
  if (!btn) return;
  state.tab = btn.dataset.tab;
  state.search = '';
  state.orderFilter = 'all';
  state.subFilter = 'pending';
  $('.sidebar').classList.remove('open');
  $('#overlay').hidden = true;
  document.body.classList.remove('nav-open');
  try {
    await loadData();
  } catch (err) {
    toast(err.message);
  }
});

$('#menuToggle').addEventListener('click', () => {
  $('.sidebar').classList.add('open');
  $('#overlay').hidden = false;
  document.body.classList.add('nav-open');
});

$('#overlay').addEventListener('click', () => {
  $('.sidebar').classList.remove('open');
  $('#overlay').hidden = true;
  document.body.classList.remove('nav-open');
});

document.addEventListener('click', async (e) => {
  const btn = e.target.closest('[data-action]');
  if (!btn) return;
  const action = btn.dataset.action;
  const id = btn.dataset.id;

  if (action === 'close-modal') {
    closeModal();
  } else if (action === 'goto') {
    state.tab = btn.dataset.tab;
    state.search = '';
    try {
      await loadData();
    } catch (err) {
      toast(err.message);
    }
  } else if (action === 'add-store') {
    openStoreForm(null);
  } else if (action === 'edit-store') {
    openStoreForm(state.data.stores.find((s) => s.id === id));
  } else if (action === 'renew-store') {
    openRenewForm(state.data.stores.find((s) => s.id === id));
  } else if (action === 'del-store') {
    const store = state.data.stores.find((s) => s.id === id);
    if (!store) return;
    if (!confirm(`حذف «${store.name}» وكل منتجاته؟ لا يمكن التراجع.`)) return;
    try {
      await api('/api/admin/store/' + id, { method: 'DELETE' });
      toast('تم حذف المحل');
      await loadData();
    } catch (err) {
      toast(err.message);
    }
  } else if (action === 'add-product') {
    if (!state.data.stores.length) return toast('أضف محلاً أولاً');
    openProductForm(null);
  } else if (action === 'edit-product') {
    openProductForm(state.data.products.find((p) => p.id === id));
  } else if (action === 'quick-price') {
    openPriceForm(state.data.products.find((p) => p.id === id));
  } else if (action === 'del-product') {
    if (!confirm('حذف هذا المنتج؟')) return;
    try {
      await api('/api/admin/product/' + id, { method: 'DELETE' });
      toast('تم حذف المنتج');
      await loadData();
    } catch (err) {
      toast(err.message);
    }
  } else if (action === 'add-banner') {
    openBannerForm(null);
  } else if (action === 'edit-banner') {
    openBannerForm((state.data.banners || []).find((b) => b.id === id));
  } else if (action === 'toggle-banner') {
    const banner = (state.data.banners || []).find((b) => b.id === id);
    if (!banner) return;
    try {
      await api('/api/admin/banner', { method: 'POST', body: { ...banner, active: !banner.active } });
      toast(banner.active ? 'تم إخفاء الإعلان' : 'تم إظهار الإعلان');
      await loadData();
    } catch (err) {
      toast(err.message);
    }
  } else if (action === 'del-banner') {
    if (!confirm('حذف هذا الإعلان؟')) return;
    try {
      await api('/api/admin/banner/' + id, { method: 'DELETE' });
      toast('تم حذف الإعلان');
      await loadData();
    } catch (err) {
      toast(err.message);
    }
  } else if (action === 'approve-submission') {
    if (!confirm('الموافقة على هذا الطلب ونشره للزوار؟')) return;
    try {
      await api('/api/admin/submission/' + id + '/approve', { method: 'POST' });
      toast('تمت الموافقة ونُشر الطلب');
      await loadData();
    } catch (err) {
      toast(err.message);
    }
  } else if (action === 'reject-submission') {
    openRejectForm((state.data.submissions || []).find((s) => s.id === id));
  } else if (action === 'del-submission') {
    if (!confirm('حذف سجل هذا الطلب نهائياً؟')) return;
    try {
      await api('/api/admin/submission/' + id, { method: 'DELETE' });
      toast('تم حذف السجل');
      await loadData();
    } catch (err) {
      toast(err.message);
    }
  } else if (action === 'add-category') {
    openCategoryForm(null);
  } else if (action === 'edit-category') {
    openCategoryForm(state.data.categories.find((c) => c.id === id));
  } else if (action === 'del-category') {
    if (!confirm('حذف هذا القسم؟')) return;
    try {
      await api('/api/admin/category/' + id, { method: 'DELETE' });
      toast('تم حذف القسم');
      await loadData();
    } catch (err) {
      toast(err.message);
    }
  }
});

document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') closeModal();
});

boot();
