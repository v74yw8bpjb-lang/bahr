@echo off
chcp 65001 >nul
title سوق حفر الباطن - سيرفر الموقع
cd /d "%~dp0"
echo.
echo   تشغيل سوق حفر الباطن...
echo.
node server.js
pause
