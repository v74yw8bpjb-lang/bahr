'use strict';

/**
 * قاعدة بيانات بسيطة تعتمد على ملف JSON واحد.
 * - كتابة ذرّية (tmp + rename) لتجنب تلف الملف.
 * - تجميع عمليات الحفظ (debounce) لتقليل ضغط القرص.
 * - بدون أي حزم خارجية.
 */

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const DATA_DIR = path.join(__dirname, 'data');
const DB_FILE = path.join(DATA_DIR, 'db.json');

let state = null;
let saveTimer = null;

const uid = (prefix) => prefix + '_' + crypto.randomBytes(6).toString('hex');
const now = () => new Date().toISOString();

/**
 * يسمح فقط بالروابط الآمنة: http(s)، أو روابط داخلية (#/)، أو صور مرفوعة (/uploads/).
 * يمنع javascript: وdata: والبروتوكولات الخطرة التي قد تُستخدم في XSS.
 */
function safeUrl(value, opts = {}) {
  const raw = String(value || '').trim().slice(0, 500);
  if (!raw) return '';
  if (/^https?:\/\/[^\s'"()<>\\]+$/i.test(raw)) return raw;
  if (/^#\/[\w\-/?=&%.]*$/i.test(raw)) return raw;
  if (/^\/uploads\/[A-Za-z0-9_-]+\.(png|jpe?g|webp)$/i.test(raw)) return raw;
  if (opts.allowDataImage && /^data:image\/(png|jpeg|webp);base64,[A-Za-z0-9+/=]+$/i.test(raw)) return raw;
  return '';
}

/* ------------------------------- كلمات المرور ------------------------------ */

function hashPassword(password, salt) {
  const s = salt || crypto.randomBytes(16).toString('hex');
  const hash = crypto.scryptSync(String(password), s, 64).toString('hex');
  return { salt: s, hash };
}

function verifyPassword(password, salt, hash) {
  if (!salt || !hash) return false;
  const candidate = crypto.scryptSync(String(password), salt, 64);
  const expected = Buffer.from(hash, 'hex');
  if (candidate.length !== expected.length) return false;
  return crypto.timingSafeEqual(candidate, expected);
}

/* --------------------------------- البذور --------------------------------- */

function seed() {
  const categories = [
    { id: 'cat_perfume', name: 'عطور', icon: '🌸' },
    { id: 'cat_coffee', name: 'قهوة مختصة', icon: '☕' },
    { id: 'cat_dates', name: 'تمور وحلويات', icon: '🍯' },
    { id: 'cat_tech', name: 'إلكترونيات', icon: '📱' },
    { id: 'cat_home', name: 'مستلزمات منزلية', icon: '🏠' },
    { id: 'cat_fashion', name: 'أزياء وعبايات', icon: '👗' },
    { id: 'cat_gifts', name: 'هدايا وورود', icon: '🎁' },
    { id: 'cat_services', name: 'خدمات', icon: '🛠️' }
  ];

  const districts = [
    { id: 'd_mohammadiya', name: 'المحمدية' },
    { id: 'd_faisaliya', name: 'الفيصلية' },
    { id: 'd_khalidiya', name: 'الخالدية' },
    { id: 'd_shifa', name: 'الشفاء' },
    { id: 'd_rawda', name: 'الروضة' },
    { id: 'd_aziziya', name: 'العزيزية' },
    { id: 'd_khaleej', name: 'الخليج' },
    { id: 'd_nahda', name: 'النهضة' }
  ];

  const year = new Date().getFullYear();
  const sub = (months) => {
    const end = new Date();
    end.setMonth(end.getMonth() + months);
    return { subStart: now(), subEnd: end.toISOString() };
  };

  const stores = [
    {
      id: 'st_oud',
      name: 'دار العود الملكي',
      categoryId: 'cat_perfume',
      districtId: 'd_mohammadiya',
      description: 'عطور شرقية وفرنسية أصلية، وتركيب عطور حسب الطلب.',
      phone: '0500000001',
      whatsapp: '966500000001',
      mapsUrl: 'https://maps.google.com/?q=حفر+الباطن+المحمدية',
      logo: '',
      cover: '',
      active: true,
      featured: true,
      ...sub(11)
    },
    {
      id: 'st_qahwa',
      name: 'قهوة الساحة',
      categoryId: 'cat_coffee',
      districtId: 'd_faisaliya',
      description: 'قهوة مختصة محمصة طازجة، أدوات تحضير، وحبوب بدرجات تحميص مختلفة.',
      phone: '0500000002',
      whatsapp: '966500000002',
      mapsUrl: 'https://maps.google.com/?q=حفر+الباطن+الفيصلية',
      logo: '',
      cover: '',
      active: true,
      featured: true,
      ...sub(6)
    },
    {
      id: 'st_tech',
      name: 'متجر التقنية',
      categoryId: 'cat_tech',
      districtId: 'd_khalidiya',
      description: 'جوالات، سماعات، شواحن أصلية، وخدمة صيانة فورية.',
      phone: '0500000003',
      whatsapp: '966500000003',
      mapsUrl: 'https://maps.google.com/?q=حفر+الباطن+الخالدية',
      logo: '',
      cover: '',
      active: true,
      featured: false,
      ...sub(3)
    },
    {
      id: 'st_dates',
      name: 'تمور الواحة',
      categoryId: 'cat_dates',
      districtId: 'd_shifa',
      description: 'تمور سكري وعجوة، معمول، وتشكيلات هدايا للمناسبات.',
      phone: '0500000004',
      whatsapp: '966500000004',
      mapsUrl: 'https://maps.google.com/?q=حفر+الباطن+الشفاء',
      logo: '',
      cover: '',
      active: true,
      featured: true,
      ...sub(9)
    },
    {
      id: 'st_roses',
      name: 'ورود الحفر',
      categoryId: 'cat_gifts',
      districtId: 'd_rawda',
      description: 'بوكيهات ورد طبيعي، تنسيق هدايا، وتوصيل داخل حفر الباطن.',
      phone: '0500000005',
      whatsapp: '966500000005',
      mapsUrl: 'https://maps.google.com/?q=حفر+الباطن+الروضة',
      logo: '',
      cover: '',
      active: true,
      featured: false,
      ...sub(2)
    },
    {
      id: 'st_abaya',
      name: 'عبايات نجد',
      categoryId: 'cat_fashion',
      districtId: 'd_aziziya',
      description: 'عبايات وأزياء نسائية بتصاميم حديثة، وتفصيل حسب المقاس.',
      phone: '0500000006',
      whatsapp: '966500000006',
      mapsUrl: 'https://maps.google.com/?q=حفر+الباطن+العزيزية',
      logo: '',
      cover: '',
      active: true,
      featured: false,
      ...sub(8)
    }
  ];

  const products = [
    ['st_oud', 'عطر عود كمبودي فاخر 50مل', 320, 'cat_perfume', true],
    ['st_oud', 'مسك الطهارة الأصلي', 45, 'cat_perfume', false],
    ['st_oud', 'بخور معمول ملكي 100جم', 180, 'cat_perfume', false],
    ['st_qahwa', 'حبوب قهوة كولومبية 250جم', 55, 'cat_coffee', true],
    ['st_qahwa', 'V60 أداة تحضير', 95, 'cat_coffee', false],
    ['st_qahwa', 'قهوة تركية مطحونة 200جم', 30, 'cat_coffee', false],
    ['st_tech', 'سماعة بلوتوث لاسلكية', 149, 'cat_tech', false],
    ['st_tech', 'شاحن سريع 65 واط', 89, 'cat_tech', false],
    ['st_tech', 'باور بانك 20000 مللي أمبير', 129, 'cat_tech', false],
    ['st_dates', 'تمر سكري فاخر 3 كيلو', 120, 'cat_dates', true],
    ['st_dates', 'معمول بالتمر علبة 24 حبة', 65, 'cat_dates', false],
    ['st_roses', 'بوكيه ورد أحمر 30 وردة', 250, 'cat_gifts', true],
    ['st_roses', 'علبة هدية ورد وشوكولاتة', 180, 'cat_gifts', false],
    ['st_abaya', 'عباية كلوش سادة', 290, 'cat_fashion', false],
    ['st_abaya', 'شيلة قطن مطرزة', 75, 'cat_fashion', false]
  ].map(([storeId, name, price, categoryId, featured]) => ({
    id: uid('pr'),
    storeId,
    name,
    price,
    oldPrice: 0,
    categoryId,
    description: '',
    image: '',
    active: true,
    featured,
    createdAt: now()
  }));

  const { salt, hash } = hashPassword(process.env.ADMIN_PASSWORD || 'admin1234');

  const banners = [
    {
      id: 'bn_weekend',
      title: 'عروض نهاية الأسبوع',
      subtitle: 'خصومات تصل إلى ٤٠٪ على العطور والبخور — من محلات حفر الباطن',
      cta: 'تسوق العروض',
      link: '#/stores',
      image: '',
      theme: 'emerald',
      active: true,
      order: 1
    },
    {
      id: 'bn_coffee',
      title: 'قهوة مختصة محمصة طازجة',
      subtitle: 'حبوب كولومبية بدرجات تحميص مختلفة — قهوة الساحة، الفيصلية',
      cta: 'زر المحل',
      link: '#/store/st_qahwa',
      image: '',
      theme: 'amber',
      active: true,
      order: 2
    },
    {
      id: 'bn_join',
      title: 'أضف محلك إلى المنصة',
      subtitle: 'وصل لعملاء حفر الباطن مباشرة عبر واتساب والخريطة',
      cta: 'تواصل معنا',
      link: 'https://wa.me/966500000000',
      image: '',
      theme: 'ink',
      active: true,
      order: 3
    }
  ];

  return {
    version: 1,
    settings: {
      siteName: 'سوق حفر الباطن',
      tagline: 'كل محلات حفر الباطن في مكان واحد',
      about: 'منصة محلية تجمع محلات وأنشطة حفر الباطن، تتصفح، تعرف السعر، وتتواصل مع التاجر مباشرة.',
      supportWhatsapp: '966500000000',
      supportPhone: '0500000000',
      primaryColor: '#0f7350',
      accentColor: '#f5a524',
      logo: '',
      passwordSalt: salt,
      passwordHash: hash
    },
    categories,
    districts,
    stores,
    products,
    banners,
    orders: [],
    submissions: []
  };
}

/* --------------------------------- القراءة -------------------------------- */

function load() {
  if (state) return state;
  fs.mkdirSync(DATA_DIR, { recursive: true });
  if (fs.existsSync(DB_FILE)) {
    try {
      state = JSON.parse(fs.readFileSync(DB_FILE, 'utf8'));
    } catch (err) {
      const backup = DB_FILE + '.broken-' + Date.now();
      fs.copyFileSync(DB_FILE, backup);
      console.error('تعذر قراءة قاعدة البيانات، تم عمل نسخة احتياطية:', backup);
      state = seed();
      persist();
    }
  } else {
    state = seed();
    persist();
  }
  if (!Array.isArray(state.banners)) state.banners = [];
  if (!Array.isArray(state.submissions)) state.submissions = [];
  const s = state.settings || (state.settings = {});
  if (!/^#[0-9a-f]{6}$/i.test(s.primaryColor || '')) s.primaryColor = '#0f7350';
  if (!/^#[0-9a-f]{6}$/i.test(s.accentColor || '')) s.accentColor = '#f5a524';
  if (s.logo === undefined) s.logo = '';
  if (!Number.isFinite(Number(state.revision))) state.revision = Date.now();
  return state;
}

/* --------------------------------- الحفظ ---------------------------------- */

function persist() {
  const tmp = DB_FILE + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(state, null, 2), 'utf8');
  fs.renameSync(tmp, DB_FILE);
}

function save() {
  const current = load();
  current.revision = Math.max(Date.now(), Number(current.revision || 0) + 1);
  if (saveTimer) clearTimeout(saveTimer);
  saveTimer = setTimeout(() => {
    saveTimer = null;
    try {
      persist();
    } catch (err) {
      console.error('فشل حفظ قاعدة البيانات:', err.message);
    }
  }, 80);
}

/** يضمن كتابة أي تعديلات معلّقة قبل إغلاق السيرفر. */
function flush() {
  if (saveTimer) {
    clearTimeout(saveTimer);
    saveTimer = null;
    persist();
  }
}

/* ------------------------------- الإعدادات -------------------------------- */

function getSettings() {
  const s = load().settings;
  return {
    siteName: s.siteName,
    tagline: s.tagline,
    about: s.about,
    supportWhatsapp: s.supportWhatsapp,
    supportPhone: s.supportPhone,
    primaryColor: s.primaryColor || '#0f7350',
    accentColor: s.accentColor || '#f5a524',
    logo: s.logo || ''
  };
}

function updateSettings(patch) {
  const db = load();
  const allowed = ['siteName', 'tagline', 'about', 'supportWhatsapp', 'supportPhone', 'primaryColor', 'accentColor', 'logo'];
  allowed.forEach((key) => {
    if (patch[key] === undefined) return;
    const value = String(patch[key] || '');
    if (key === 'primaryColor' || key === 'accentColor') {
      if (/^#[0-9a-f]{6}$/i.test(value)) db.settings[key] = value.toLowerCase();
    } else if (key === 'logo') {
      db.settings.logo = safeUrl(value);
    } else {
      db.settings[key] = value.slice(0, 400);
    }
  });
  save();
  return getSettings();
}

function setPassword(password) {
  const db = load();
  const { salt, hash } = hashPassword(password);
  db.settings.passwordSalt = salt;
  db.settings.passwordHash = hash;
  save();
}

function checkPassword(password) {
  const s = load().settings;
  return verifyPassword(password, s.passwordSalt, s.passwordHash);
}

/** بصمة مشتقة من تجزئة الرمز — تُستخدم لربط الجلسات بالرمز الحالي. */
function passwordFingerprint() {
  const s = load().settings;
  return crypto.createHash('sha256').update(String(s.passwordHash || '')).digest('hex');
}

/** هل ما زال المدير يستخدم الرمز الافتراضي؟ */
function usingDefaultPassword() {
  return checkPassword('admin1234');
}

/* -------------------------------- المساعدات ------------------------------- */

function subscriptionActive(store) {
  if (!store.active) return false;
  const t = Date.now();
  if (store.subStart && new Date(store.subStart).getTime() > t) return false;
  if (store.subEnd && new Date(store.subEnd).getTime() < t) return false;
  return true;
}

/** بيانات الواجهة العامة: محلات فعّالة فقط، ومنتجات محلات فعّالة فقط. */
function publicData() {
  const db = load();
  const liveStores = db.stores.filter(subscriptionActive);
  const liveIds = new Set(liveStores.map((s) => s.id));
  return {
    revision: load().revision || 0,
    settings: getSettings(),
    categories: db.categories,
    districts: db.districts,
    stores: liveStores.map((s) => ({ ...s, password: undefined })),
    products: db.products.filter((p) => p.active && liveIds.has(p.storeId)),
    banners: (db.banners || []).filter((b) => b.active).sort((a, b) => (a.order || 0) - (b.order || 0))
  };
}

/** رقم إصدار البيانات — يتغير مع أي تعديل من لوحة التحكم. */
function revision() {
  return load().revision || 0;
}

function adminData() {
  const db = load();
  return {
    settings: getSettings(),
    categories: db.categories,
    districts: db.districts,
    stores: db.stores.map((s) => ({ ...s, live: subscriptionActive(s) })),
    products: db.products,
    banners: (db.banners || []).slice().sort((a, b) => (a.order || 0) - (b.order || 0)),
    orders: db.orders.slice().sort((a, b) => b.createdAt.localeCompare(a.createdAt)),
    submissions: (db.submissions || [])
      .slice()
      .sort((a, b) => (a.status === 'pending' ? 0 : 1) - (b.status === 'pending' ? 0 : 1) || b.createdAt.localeCompare(a.createdAt)),
    security: {
      usingDefaultPassword: usingDefaultPassword()
    }
  };
}

/** عدّادات التنبيهات للوحة التحكم (تُستخدم في التحديث الدوري). */
function notifications() {
  const db = load();
  const t = Date.now();
  const expiring = db.stores.filter((s) => {
    if (!subscriptionActive(s) || !s.subEnd) return false;
    const days = Math.ceil((new Date(s.subEnd).getTime() - t) / 86400000);
    return days >= 0 && days <= 14;
  }).length;
  return {
    pendingSubmissions: (db.submissions || []).filter((s) => s.status === 'pending').length,
    newOrders: db.orders.filter((o) => o.status === 'new').length,
    expiringStores: expiring
  };
}

/* --------------------------------- المحلات -------------------------------- */

function upsertStore(input) {
  const db = load();
  const clean = {
    name: String(input.name || '').trim().slice(0, 80),
    categoryId: String(input.categoryId || ''),
    districtId: String(input.districtId || ''),
    description: String(input.description || '').slice(0, 500),
    phone: String(input.phone || '').slice(0, 30),
    whatsapp: String(input.whatsapp || '').replace(/[^\d]/g, '').slice(0, 20),
    mapsUrl: safeUrl(input.mapsUrl),
    logo: safeUrl(input.logo),
    cover: safeUrl(input.cover),
    active: !!input.active,
    featured: !!input.featured,
    subStart: input.subStart || now(),
    subEnd: input.subEnd || ''
  };
  if (!clean.name) throw new Error('اسم المحل مطلوب');

  if (input.id) {
    const store = db.stores.find((s) => s.id === input.id);
    if (!store) throw new Error('المحل غير موجود');
    Object.assign(store, clean, { updatedAt: now() });
    save();
    return store;
  }

  const store = { id: uid('st'), ...clean, createdAt: now() };
  db.stores.push(store);
  save();
  return store;
}

function deleteStore(id) {
  const db = load();
  const idx = db.stores.findIndex((s) => s.id === id);
  if (idx === -1) throw new Error('المحل غير موجود');
  db.stores.splice(idx, 1);
  db.products = db.products.filter((p) => p.storeId !== id);
  save();
}

/** تمديد الاشتراك من تاريخ الانتهاء الحالي (أو من اليوم إذا كان منتهياً). */
function renewStore(id, months) {
  const db = load();
  const store = db.stores.find((s) => s.id === id);
  if (!store) throw new Error('المحل غير موجود');
  const count = Math.max(1, Math.min(36, Number(months) || 12));
  const currentEnd = store.subEnd ? new Date(store.subEnd).getTime() : 0;
  const base = new Date(Math.max(Date.now(), currentEnd));
  const day = base.getDate();
  base.setDate(1);
  base.setMonth(base.getMonth() + count);
  const lastDay = new Date(base.getFullYear(), base.getMonth() + 1, 0).getDate();
  base.setDate(Math.min(day, lastDay));
  if (!store.subStart) store.subStart = now();
  store.subEnd = base.toISOString();
  store.active = true;
  save();
  return store;
}

/* -------------------------------- المنتجات -------------------------------- */

function upsertProduct(input) {
  const db = load();
  const price = Number(input.price);
  if (!input.name || !String(input.name).trim()) throw new Error('اسم المنتج مطلوب');
  if (!Number.isFinite(price) || price < 0) throw new Error('السعر غير صحيح');
  if (!db.stores.some((s) => s.id === input.storeId)) throw new Error('المحل غير موجود');

  const clean = {
    name: String(input.name).trim().slice(0, 120),
    storeId: String(input.storeId),
    categoryId: String(input.categoryId || ''),
    price: Math.round(price * 100) / 100,
    oldPrice: Number(input.oldPrice) > 0 ? Math.round(Number(input.oldPrice) * 100) / 100 : 0,
    description: String(input.description || '').slice(0, 500),
    image: safeUrl(input.image),
    active: input.active !== false,
    featured: !!input.featured
  };

  if (input.id) {
    const product = db.products.find((p) => p.id === input.id);
    if (!product) throw new Error('المنتج غير موجود');
    Object.assign(product, clean, { updatedAt: now() });
    save();
    return product;
  }

  const product = { id: uid('pr'), ...clean, createdAt: now() };
  db.products.push(product);
  save();
  return product;
}

function deleteProduct(id) {
  const db = load();
  const idx = db.products.findIndex((p) => p.id === id);
  if (idx === -1) throw new Error('المنتج غير موجود');
  db.products.splice(idx, 1);
  save();
}

/* --------------------------------- الأقسام -------------------------------- */

function upsertCategory(input) {
  const db = load();
  const name = String(input.name || '').trim().slice(0, 40);
  if (!name) throw new Error('اسم القسم مطلوب');
  if (input.id) {
    const cat = db.categories.find((c) => c.id === input.id);
    if (!cat) throw new Error('القسم غير موجود');
    cat.name = name;
    if (input.icon !== undefined) cat.icon = String(input.icon).slice(0, 8);
    if (input.image !== undefined) cat.image = safeUrl(input.image);
    save();
    return cat;
  }
  const cat = {
    id: uid('cat'),
    name,
    icon: String(input.icon || '📦').slice(0, 8),
    image: safeUrl(input.image)
  };
  db.categories.push(cat);
  save();
  return cat;
}

function deleteCategory(id) {
  const db = load();
  db.categories = db.categories.filter((c) => c.id !== id);
  save();
}

/* -------------------------------- الإعلانات ------------------------------- */

function upsertBanner(input) {
  const db = load();
  const title = String(input.title || '').trim().slice(0, 80);
  if (!title) throw new Error('عنوان الإعلان مطلوب');

  const clean = {
    title,
    subtitle: String(input.subtitle || '').slice(0, 180),
    cta: String(input.cta || '').slice(0, 30),
    link: safeUrl(input.link) || '#/',
    image: safeUrl(input.image),
    theme: ['emerald', 'amber', 'ink'].includes(input.theme) ? input.theme : 'emerald',
    active: input.active !== false,
    order: Number(input.order) || 0
  };

  if (input.id) {
    const banner = db.banners.find((b) => b.id === input.id);
    if (!banner) throw new Error('الإعلان غير موجود');
    Object.assign(banner, clean);
    save();
    return banner;
  }

  const banner = { id: uid('bn'), ...clean };
  db.banners.push(banner);
  save();
  return banner;
}

function deleteBanner(id) {
  const db = load();
  const idx = db.banners.findIndex((b) => b.id === id);
  if (idx === -1) throw new Error('الإعلان غير موجود');
  db.banners.splice(idx, 1);
  save();
}

/* -------------------------- طلبات واقتراحات العملاء ------------------------ */

const SUBMISSION_IMAGE = /^\/uploads\/[A-Za-z0-9_-]+\.(png|jpe?g|webp)$/i;

function createSubmission(input) {
  const db = load();
  const type = input.type === 'image' ? 'image' : 'product';
  const store = db.stores.find((s) => s.id === input.storeId && subscriptionActive(s));
  if (!store) throw new Error('المحل غير متاح حالياً');

  const customerName = String(input.customerName || '').trim().slice(0, 60);
  const phone = String(input.phone || '').replace(/[^\d+]/g, '').slice(0, 20);
  if (customerName.length < 2) throw new Error('الاسم مطلوب');
  if (phone.replace(/\D/g, '').length < 9) throw new Error('رقم الجوال غير صحيح');

  const image = String(input.image || '');
  if (image && !SUBMISSION_IMAGE.test(image)) throw new Error('صورة غير صالحة');

  const base = {
    type,
    storeId: store.id,
    storeName: store.name,
    customerName,
    phone,
    note: String(input.note || '').slice(0, 400),
    status: 'pending',
    createdAt: now()
  };

  let submission;
  if (type === 'image') {
    const product = db.products.find((p) => p.id === input.productId && p.storeId === store.id);
    if (!product) throw new Error('المنتج غير موجود في هذا المحل');
    if (!image) throw new Error('ارفع صورة المنتج أولاً');
    submission = {
      ...base,
      productId: product.id,
      productName: product.name,
      name: product.name,
      price: product.price,
      categoryId: product.categoryId || store.categoryId,
      description: product.description || '',
      image
    };
  } else {
    const name = String(input.name || '').trim().slice(0, 120);
    const price = Number(input.price);
    if (!name) throw new Error('اسم المنتج مطلوب');
    if (!Number.isFinite(price) || price < 0) throw new Error('السعر غير صحيح');
    const categoryId = db.categories.some((c) => c.id === input.categoryId) ? input.categoryId : store.categoryId;
    submission = {
      ...base,
      productId: '',
      productName: name,
      name,
      price: Math.round(price * 100) / 100,
      categoryId,
      description: String(input.description || '').slice(0, 500),
      image
    };
  }

  submission.id = uid('sub');
  db.submissions.push(submission);
  if (db.submissions.length > 1000) db.submissions = db.submissions.slice(-1000);
  save();
  return submission;
}

function approveSubmission(id) {
  const db = load();
  const sub = db.submissions.find((s) => s.id === id);
  if (!sub) throw new Error('الطلب غير موجود');
  if (sub.status !== 'pending') throw new Error('تمت مراجعة هذا الطلب مسبقاً');

  if (sub.type === 'image') {
    const product = db.products.find((p) => p.id === sub.productId);
    if (!product) throw new Error('المنتج لم يعد موجوداً');
    product.image = sub.image;
    product.updatedAt = now();
    sub.productId = product.id;
    sub.productName = product.name;
  } else {
    const product = upsertProduct({
      name: sub.name,
      storeId: sub.storeId,
      categoryId: sub.categoryId,
      price: sub.price,
      description: sub.description,
      image: sub.image,
      active: true,
      featured: false
    });
    sub.createdProductId = product.id;
    sub.productId = product.id;
    sub.productName = product.name;
  }

  sub.status = 'approved';
  sub.reviewedAt = now();
  save();
  return sub;
}

function rejectSubmission(id, reason) {
  const db = load();
  const sub = db.submissions.find((s) => s.id === id);
  if (!sub) throw new Error('الطلب غير موجود');
  if (sub.status !== 'pending') throw new Error('تمت مراجعة هذا الطلب مسبقاً');
  sub.status = 'rejected';
  sub.rejectReason = String(reason || '').slice(0, 300);
  sub.reviewedAt = now();
  save();
  return sub;
}

function deleteSubmission(id) {
  const db = load();
  const idx = db.submissions.findIndex((s) => s.id === id);
  if (idx === -1) throw new Error('الطلب غير موجود');
  db.submissions.splice(idx, 1);
  save();
}

/* --------------------------------- الطلبات -------------------------------- */

function createOrder(input) {
  const db = load();
  const items = Array.isArray(input.items) ? input.items.slice(0, 100) : [];
  if (!items.length) throw new Error('السلة فارغة');

  const phone = String(input.phone || '').replace(/[^\d+]/g, '');
  if (phone.replace(/\D/g, '').length < 9) throw new Error('رقم الجوال غير صحيح');

  const lines = [];
  for (const line of items) {
    const product = db.products.find((p) => p.id === line.productId && p.active);
    if (!product) continue;
    const store = db.stores.find((s) => s.id === product.storeId);
    if (!store || !subscriptionActive(store)) continue;
    const qty = Math.max(1, Math.min(99, Number(line.qty) || 1));
    lines.push({
      productId: product.id,
      name: product.name,
      price: product.price,
      qty,
      storeId: store.id,
      storeName: store.name,
      storeWhatsapp: store.whatsapp
    });
  }
  if (!lines.length) throw new Error('المنتجات المطلوبة غير متاحة حالياً');

  const total = lines.reduce((sum, l) => sum + l.price * l.qty, 0);
  db.orderSeq = (Number(db.orderSeq) || 0) + 1;
  const seq = db.orderSeq;
  const order = {
    id: uid('or'),
    number: 'HB-' + String(1000 + seq),
    customerName: String(input.customerName || '').slice(0, 60) || 'زبون',
    phone,
    note: String(input.note || '').slice(0, 400),
    items: lines,
    total: Math.round(total * 100) / 100,
    status: 'new',
    createdAt: now()
  };
  db.orders.push(order);
  if (db.orders.length > 5000) db.orders = db.orders.slice(-5000);
  save();
  return order;
}

function setOrderStatus(id, status) {
  const db = load();
  const order = db.orders.find((o) => o.id === id);
  if (!order) throw new Error('الطلب غير موجود');
  const allowed = ['new', 'contacted', 'done', 'cancelled'];
  if (!allowed.includes(status)) throw new Error('حالة غير معروفة');
  order.status = status;
  save();
  return order;
}

module.exports = {
  load,
  flush,
  getSettings,
  updateSettings,
  setPassword,
  checkPassword,
  passwordFingerprint,
  usingDefaultPassword,
  publicData,
  revision,
  adminData,
  notifications,
  subscriptionActive,
  upsertStore,
  deleteStore,
  renewStore,
  upsertProduct,
  deleteProduct,
  upsertCategory,
  deleteCategory,
  upsertBanner,
  deleteBanner,
  createSubmission,
  approveSubmission,
  rejectSubmission,
  deleteSubmission,
  createOrder,
  setOrderStatus,
  uid
};
