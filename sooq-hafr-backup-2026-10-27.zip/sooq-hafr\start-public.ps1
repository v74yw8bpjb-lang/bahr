﻿# تشغيل الموقع للإنترنت عبر Cloudflare Tunnel (رابط مؤقت)
# الاستخدام: كليك يمين على start-public.bat ثم Run

$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$port = 8080
$cf = Join-Path $env:LOCALAPPDATA 'cloudflared\cloudflared.exe'

if (-not (Test-Path $cf)) {
  Write-Host 'cloudflared غير مثبت. سيتم تحميله الآن...' -ForegroundColor Yellow
  $dir = Split-Path -Parent $cf
  New-Item -ItemType Directory -Force -Path $dir | Out-Null
  Invoke-WebRequest -Uri 'https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-windows-amd64.exe' -OutFile $cf -UseBasicParsing
}

$listening = Get-NetTCPConnection -LocalPort $port -State Listen -ErrorAction SilentlyContinue
if (-not $listening) {
  Write-Host 'تشغيل سيرفر الموقع...' -ForegroundColor Cyan
  $env:TRUST_PROXY = '1'
  Start-Process -FilePath node -ArgumentList 'server.js' -WorkingDirectory $root -WindowStyle Hidden
  Start-Sleep -Seconds 2
} else {
  Write-Host 'سيرفر الموقع يعمل بالفعل على المنفذ 8080.' -ForegroundColor Green
}

$out = Join-Path $env:LOCALAPPDATA 'cloudflared\tunnel.out.log'
$err = Join-Path $env:LOCALAPPDATA 'cloudflared\tunnel.err.log'
Remove-Item $out, $err -Force -ErrorAction SilentlyContinue

Write-Host 'فتح النفق العام...' -ForegroundColor Cyan
Start-Process -FilePath $cf -ArgumentList 'tunnel', '--url', "http://localhost:$port", '--no-autoupdate' -RedirectStandardOutput $out -RedirectStandardError $err -WindowStyle Hidden

$url = $null
for ($i = 0; $i -lt 30; $i++) {
  Start-Sleep -Seconds 1
  if (Test-Path $err) {
    $match = Select-String -Path $err -Pattern 'https://[a-z0-9-]+\.trycloudflare\.com' -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($match) { $url = $match.Matches.Value; break }
  }
}

Write-Host ''
if ($url) {
  Write-Host '========================================' -ForegroundColor Green
  Write-Host '  رابط الموقع العام:' -ForegroundColor Green
  Write-Host "  $url" -ForegroundColor Yellow
  Write-Host '  لوحة التحكم:' -ForegroundColor Green
  Write-Host "  $url/admin" -ForegroundColor Yellow
  Write-Host '========================================' -ForegroundColor Green
  Write-Host ''
  Write-Host 'الرابط مؤقت ويتغير عند إعادة التشغيل.' -ForegroundColor Gray
  Write-Host 'جهازك لازم يظل شغالاً والنفق مفتوحاً.' -ForegroundColor Gray
} else {
  Write-Host 'تعذر قراءة الرابط. راجع السجل:' -ForegroundColor Red
  Write-Host $err
}

Write-Host ''
Read-Host 'اضغط Enter للإغلاق'
