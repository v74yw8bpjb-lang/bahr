'use strict';

/**
 * توليد أيقونات التطبيق (PNG) بدون أي مكتبات خارجية.
 * التشغيل: node tools/gen-icons.js
 */

const fs = require('fs');
const path = require('path');
const zlib = require('zlib');

const OUT = path.join(__dirname, '..', 'public', 'icons');

/* ------------------------------- أدوات PNG -------------------------------- */

const CRC_TABLE = (() => {
  const table = new Int32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    table[n] = c;
  }
  return table;
})();

function crc32(buf) {
  let c = 0xffffffff;
  for (let i = 0; i < buf.length; i++) c = CRC_TABLE[(c ^ buf[i]) & 0xff] ^ (c >>> 8);
  return (c ^ 0xffffffff) >>> 0;
}

function chunk(type, data) {
  const len = Buffer.alloc(4);
  len.writeUInt32BE(data.length);
  const typeBuf = Buffer.from(type, 'ascii');
  const crc = Buffer.alloc(4);
  crc.writeUInt32BE(crc32(Buffer.concat([typeBuf, data])));
  return Buffer.concat([len, typeBuf, data, crc]);
}

function encodePng(width, height, rgba) {
  const raw = Buffer.alloc((width * 4 + 1) * height);
  for (let y = 0; y < height; y++) {
    raw[y * (width * 4 + 1)] = 0; // filter: none
    rgba.copy(raw, y * (width * 4 + 1) + 1, y * width * 4, (y + 1) * width * 4);
  }
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(width, 0);
  ihdr.writeUInt32BE(height, 4);
  ihdr[8] = 8; // bit depth
  ihdr[9] = 6; // RGBA
  return Buffer.concat([
    Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]),
    chunk('IHDR', ihdr),
    chunk('IDAT', zlib.deflateSync(raw, { level: 9 })),
    chunk('IEND', Buffer.alloc(0))
  ]);
}

/* --------------------------------- الرسم ---------------------------------- */

const TEAL = [15, 107, 79];
const TEAL_DARK = [10, 61, 46];
const WHITE = [255, 255, 255];
const GOLD = [201, 162, 39];

function insideRoundRect(u, v, x0, y0, x1, y1, r) {
  const cx = Math.min(Math.max(u, x0 + r), x1 - r);
  const cy = Math.min(Math.max(v, y0 + r), y1 - r);
  return (u - cx) ** 2 + (v - cy) ** 2 <= r * r;
}

function insideRect(u, v, x0, y0, x1, y1) {
  return u >= x0 && u <= x1 && v >= y0 && v <= y1;
}

/** يعيد لون النقطة (u,v) داخل مربع الوحدة. */
function paint(u, v) {
  // خلفية متدرجة بحواف دائرية
  if (!insideRoundRect(u, v, 0, 0, 1, 1, 0.22)) return null;
  const t = (u + v) / 2;
  const bg = [
    Math.round(TEAL[0] + (TEAL_DARK[0] - TEAL[0]) * t),
    Math.round(TEAL[1] + (TEAL_DARK[1] - TEAL[1]) * t),
    Math.round(TEAL[2] + (TEAL_DARK[2] - TEAL[2]) * t)
  ];

  // جسم المتجر
  if (insideRoundRect(u, v, 0.25, 0.30, 0.75, 0.73, 0.04)) {
    // مظلة ذهبية
    if (insideRect(u, v, 0.25, 0.30, 0.75, 0.385)) return GOLD;
    // باب
    if (insideRoundRect(u, v, 0.435, 0.49, 0.565, 0.73, 0.02)) return TEAL_DARK;
    // واجهات العرض
    if (insideRect(u, v, 0.305, 0.455, 0.395, 0.545)) return TEAL_DARK;
    if (insideRect(u, v, 0.605, 0.455, 0.695, 0.545)) return TEAL_DARK;
    return WHITE;
  }

  return bg;
}

function render(size, samples = 3) {
  const rgba = Buffer.alloc(size * size * 4);
  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      let r = 0, g = 0, b = 0, a = 0;
      for (let sy = 0; sy < samples; sy++) {
        for (let sx = 0; sx < samples; sx++) {
          const u = (x + (sx + 0.5) / samples) / size;
          const v = (y + (sy + 0.5) / samples) / size;
          const c = paint(u, v);
          if (c) {
            r += c[0]; g += c[1]; b += c[2]; a += 255;
          }
        }
      }
      const n = samples * samples;
      const i = (y * size + x) * 4;
      const covered = a / 255; // عدد العينات المغطاة
      rgba[i] = covered ? Math.round(r / covered) : 0;
      rgba[i + 1] = covered ? Math.round(g / covered) : 0;
      rgba[i + 2] = covered ? Math.round(b / covered) : 0;
      rgba[i + 3] = Math.round((a / n));
    }
  }
  return encodePng(size, size, rgba);
}

fs.mkdirSync(OUT, { recursive: true });
[[512, 2], [192, 3], [180, 3]].forEach(([size, samples]) => {
  const file = path.join(OUT, `icon-${size}.png`);
  fs.writeFileSync(file, render(size, samples));
  console.log('تم إنشاء', file);
});
