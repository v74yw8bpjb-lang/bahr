'use strict';

/* ===========================================================
   سوق حفر الباطن — واجهة الزوار
   =========================================================== */

const $ = (sel, root = document) => root.querySelector(sel);
const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));

const CART_KEY = 'hb_cart_v1';

const state = {
  data: null,
  revision: 0,
  refreshing: false,
  cart: loadCart(),
  filters: { cat: '', district: '', q: '', sort: 'new' }
};

const ICONS = {
  wa: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M20.5 11.6a8.4 8.4 0 0 1-12.3 7.5L3.5 20.5l1.4-4.6A8.4 8.4 0 1 1 20.5 11.6Z"/><path d="M8.6 8.9c.2-.5.5-.5.8-.5h.6c.2 0 .4 0 .6.4l.7 1.6c.1.2 0 .4-.1.6l-.4.5c-.1.2-.2.3 0 .6.5.8 1.1 1.4 1.9 1.8.3.2.4.1.6-.1l.5-.5c.2-.2.4-.2.6-.1l1.6.7c.3.2.4.3.4.5 0 .7-.3 1.5-1.3 1.7-1.6.3-3.6-.6-5-2s-2.3-3.4-1.9-4.8c.1-.3.3-.6.4-.8Z"/></svg>',
  plus: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3 4h2l2.4 11.2A2 2 0 0 0 9.4 17h8.4a2 2 0 0 0 2-1.6L21 8H6"/><circle cx="10" cy="20" r="1.4"/><circle cx="18" cy="20" r="1.4"/><path d="M13.5 9.8v4.4M11.3 12h4.4"/></svg>',
  arrow: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M14 6l-6 6 6 6"/></svg>'
};

/* -------------------------------- أدوات عامة ------------------------------- */

function escapeHtml(value) {
  return String(value == null ? '' : value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

/** رابط آمن للاستخدام في href فقط. */
function safeHref(value) {
  const raw = String(value || '').trim();
  if (/^https?:\/\/[^\s'"()<>\\]+$/i.test(raw)) return raw;
  if (/^#\/[\w\-/?=&%.]*$/i.test(raw)) return raw;
  if (/^\/uploads\/[A-Za-z0-9_-]+\.(png|jpe?g|webp)$/i.test(raw)) return raw;
  return '#/';
}

/** مصدر صورة آمن فقط. */
function safeImage(value) {
  const raw = String(value || '').trim();
  if (/^https?:\/\/[^\s'"()<>\\]+$/i.test(raw)) return raw;
  if (/^\/uploads\/[A-Za-z0-9_-]+\.(png|jpe?g|webp)$/i.test(raw)) return raw;
  if (/^data:image\/(png|jpeg|webp);base64,[A-Za-z0-9+/=]+$/i.test(raw)) return raw;
  return '';
}

function money(n) {
  const num = Number(n) || 0;
  const text = num % 1 === 0 ? String(num) : num.toFixed(2);
  return text.replace(/\B(?=(\d{3})+(?!\d))/g, ',');
}

/* ------------------------------ ألوان الموقع ------------------------------- */

function hexToHsl(hex) {
  const m = /^#?([0-9a-f]{6})$/i.exec(String(hex || ''));
  if (!m) return null;
  const n = parseInt(m[1], 16);
  const r = ((n >> 16) & 255) / 255;
  const g = ((n >> 8) & 255) / 255;
  const b = (n & 255) / 255;
  const max = Math.max(r, g, b);
  const min = Math.min(r, g, b);
  const l = (max + min) / 2;
  const d = max - min;
  let h = 0;
  let s = 0;
  if (d) {
    s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
    if (max === r) h = (g - b) / d + (g < b ? 6 : 0);
    else if (max === g) h = (b - r) / d + 2;
    else h = (r - g) / d + 4;
    h *= 60;
  }
  return { h, s: s * 100, l: l * 100 };
}

function hslToHex(h, s, l) {
  s = Math.max(0, Math.min(100, s)) / 100;
  l = Math.max(0, Math.min(100, l)) / 100;
  const c = (1 - Math.abs(2 * l - 1)) * s;
  const x = c * (1 - Math.abs(((h / 60) % 2) - 1));
  const m = l - c / 2;
  let r = 0;
  let g = 0;
  let b = 0;
  if (h < 60) { r = c; g = x; }
  else if (h < 120) { r = x; g = c; }
  else if (h < 180) { g = c; b = x; }
  else if (h < 240) { g = x; b = c; }
  else if (h < 300) { r = x; b = c; }
  else { r = c; b = x; }
  const to = (v) => Math.round((v + m) * 255).toString(16).padStart(2, '0');
  return '#' + to(r) + to(g) + to(b);
}

function applyTheme(settings) {
  const root = document.documentElement;
  const p = hexToHsl(settings.primaryColor) || hexToHsl('#0f7350');
  const a = hexToHsl(settings.accentColor) || hexToHsl('#f5a524');

  const brand = { 950: p.l - 22, 900: p.l - 17, 800: p.l - 12, 700: p.l - 7, 600: p.l, 500: p.l + 7, 200: p.l + 45, 100: p.l + 52, 50: p.l + 57 };
  const brandSat = { 950: 0, 900: 0, 800: 0, 700: 0, 600: 0, 500: -2, 200: -12, 100: -18, 50: -22 };
  Object.keys(brand).forEach((key) => {
    root.style.setProperty('--brand-' + key, hslToHex(p.h, p.s + (brandSat[key] || 0), Math.max(3, Math.min(97, brand[key]))));
  });

  const accent = { 700: a.l - 14, 600: a.l - 7, 500: a.l, 400: a.l + 8, 50: Math.max(94, a.l + 45) };
  const accentSat = { 700: 0, 600: 0, 500: 0, 400: -3, 50: -30 };
  Object.keys(accent).forEach((key) => {
    root.style.setProperty('--amber-' + key, hslToHex(a.h, a.s + (accentSat[key] || 0), Math.max(3, Math.min(97, accent[key]))));
  });

  const meta = document.querySelector('meta[name="theme-color"]');
  if (meta) meta.content = hslToHex(p.h, p.s, Math.max(3, p.l - 17));
}

function applyBranding(settings) {
  applyTheme(settings);
  const logoSrc = safeImage(settings.logo);
  $$('.logo').forEach((el) => {
    if (!logoSrc) {
      if (el.classList.contains('has-image')) {
        el.textContent = 'ح';
        el.classList.remove('has-image');
      }
      return;
    }
    const img = document.createElement('img');
    img.src = logoSrc;
    img.alt = '';
    el.textContent = '';
    el.appendChild(img);
    el.classList.add('has-image');
  });
  const icon = document.querySelector('link[rel="icon"]');
  if (icon) {
    if (!icon.dataset.default) icon.dataset.default = icon.getAttribute('href') || '';
    icon.href = logoSrc || icon.dataset.default;
  }
}

/** تطبيق اسم الموقع والنصوص المشتركة في الترويسة والتذييل. */
function applySiteSettings(settings) {
  applyBranding(settings);
  document.title = settings.siteName;
  $('#siteName').textContent = settings.siteName;
  $('#tagline').textContent = settings.tagline;
  $('#footerName').textContent = settings.siteName;
  $('#footerAbout').textContent = settings.about;
  $('#supportLink').href = waLink(settings.supportWhatsapp, 'مرحباً، عندي استفسار عن سوق حفر الباطن');
}

function hueFor(text) {
  let hash = 0;
  for (let i = 0; i < String(text).length; i++) hash = (hash * 31 + String(text).charCodeAt(i)) % 360;
  return hash;
}

function categoryOf(id) {
  return (state.data?.categories || []).find((c) => c.id === id);
}

function districtOf(id) {
  return (state.data?.districts || []).find((d) => d.id === id);
}

function storeOf(id) {
  return (state.data?.stores || []).find((s) => s.id === id);
}

function productOf(id) {
  return (state.data?.products || []).find((p) => p.id === id);
}

function iconOf(product) {
  const cat = categoryOf(product.categoryId) || categoryOf(storeOf(product.storeId)?.categoryId);
  return cat?.icon || '🛍️';
}

function catIconMarkup(cat) {
  if (!cat) return '📦';
  const image = safeImage(cat.image);
  if (image) {
    return `<img src="${escapeHtml(image)}" alt="${escapeHtml(cat.name || '')}" loading="lazy">`;
  }
  return escapeHtml(cat.icon || '📦');
}

function thumbMarkup(src, icon, name) {
  const image = safeImage(src);
  if (image) return `<img src="${escapeHtml(image)}" alt="${escapeHtml(name)}" loading="lazy">`;
  const hue = hueFor(name);
  return `<span style="background:linear-gradient(150deg,hsl(${hue} 42% 96%),hsl(${hue} 38% 89%))">${escapeHtml(icon)}</span>`;
}

function waLink(number, text) {
  const digits = String(number || '').replace(/\D/g, '');
  const normalized = digits.startsWith('966') ? digits : digits.startsWith('0') ? '966' + digits.slice(1) : digits;
  return 'https://wa.me/' + normalized + '?text=' + encodeURIComponent(text || '');
}

function toast(message) {
  const el = $('#toast');
  el.textContent = message;
  el.classList.add('show');
  clearTimeout(toast.timer);
  toast.timer = setTimeout(() => el.classList.remove('show'), 2400);
}

/* --------------------------------- السلة ---------------------------------- */

function loadCart() {
  try {
    const raw = JSON.parse(localStorage.getItem(CART_KEY) || '[]');
    return Array.isArray(raw) ? raw.filter((l) => l && l.productId && l.qty > 0) : [];
  } catch (err) {
    return [];
  }
}

function saveCart() {
  localStorage.setItem(CART_KEY, JSON.stringify(state.cart));
  renderCartBadge();
}

function cartCount() {
  return state.cart.reduce((sum, line) => sum + line.qty, 0);
}

function cartTotal() {
  return state.cart.reduce((sum, line) => {
    const product = productOf(line.productId);
    return sum + (product ? product.price * line.qty : 0);
  }, 0);
}

function addToCart(productId, qty = 1) {
  const product = productOf(productId);
  if (!product) return;
  const line = state.cart.find((l) => l.productId === productId);
  if (line) line.qty = Math.min(99, line.qty + qty);
  else state.cart.push({ productId, qty });
  saveCart();
  toast('تمت الإضافة إلى السلة: ' + product.name);
}

function changeQty(productId, delta) {
  const line = state.cart.find((l) => l.productId === productId);
  if (!line) return;
  line.qty += delta;
  if (line.qty <= 0) state.cart = state.cart.filter((l) => l.productId !== productId);
  saveCart();
  renderCart();
}

function removeFromCart(productId) {
  state.cart = state.cart.filter((l) => l.productId !== productId);
  saveCart();
  renderCart();
}

function renderCartBadge() {
  const count = cartCount();
  ['cartCount', 'navCartCount'].forEach((id) => {
    const el = document.getElementById(id);
    if (!el) return;
    el.textContent = count;
    el.hidden = count === 0;
  });
}

/* -------------------------------- المكونات -------------------------------- */

function productCard(product) {
  const store = storeOf(product.storeId);
  const district = districtOf(store?.districtId);
  const msg = `مرحباً ${store?.name || ''}، أرغب بالاستفسار عن: ${product.name} (${money(product.price)} ر.س) — عبر سوق حفر الباطن`;

  return `
    <article class="product" data-product="${escapeHtml(product.id)}">
      <button class="thumb" data-action="open-product" data-id="${escapeHtml(product.id)}" aria-label="${escapeHtml(product.name)}">
        ${thumbMarkup(product.image, iconOf(product), product.name)}
        ${product.featured ? '<span class="tag">مميز</span>' : ''}
      </button>
      <div class="product-body">
        <h3 class="product-name">${escapeHtml(product.name)}</h3>
        <div class="product-store">
          <span>${escapeHtml(store?.name || '')}</span>
          <span class="dot"></span>
          <span>${escapeHtml(district?.name || '')}</span>
        </div>
        <div class="price-row">
          <span class="price">${money(product.price)} <small>ر.س</small>
            ${product.oldPrice > product.price ? `<span class="price-old">${money(product.oldPrice)}</span>` : ''}
          </span>
          <div class="product-actions">
            <a class="round-btn wa" href="${escapeHtml(waLink(store?.whatsapp, msg))}" target="_blank" rel="noopener" aria-label="واتساب المحل">${ICONS.wa}</a>
            <button class="round-btn primary" data-action="add" data-id="${escapeHtml(product.id)}" aria-label="أضف للسلة">${ICONS.plus}</button>
          </div>
        </div>
      </div>
    </article>`;
}

function storeCard(store, withActions) {
  const district = districtOf(store.districtId);
  const cat = categoryOf(store.categoryId);
  const productCount = (state.data.products || []).filter((p) => p.storeId === store.id).length;
  const storeLogo = safeImage(store.logo);
  const logo = storeLogo
    ? `<img src="${escapeHtml(storeLogo)}" alt="${escapeHtml(store.name)}">`
    : escapeHtml(store.name.slice(0, 1));

  return `
    <article class="store-card">
      <div class="store-logo">${logo}</div>
      <div class="store-info">
        <div class="store-name">
          <a href="#/store/${escapeHtml(store.id)}">${escapeHtml(store.name)}</a>
          ${store.featured ? '<span class="star">مميز</span>' : ''}
        </div>
        <div class="store-meta">${escapeHtml(cat?.name || '')} • ${escapeHtml(district?.name || '')} • ${productCount} منتج</div>
        <div class="store-desc">${escapeHtml(store.description || '')}</div>
        ${withActions ? `
        <div class="product-actions" style="margin-top:10px">
          <a class="btn btn-primary btn-sm" href="#/store/${escapeHtml(store.id)}">تصفح المحل</a>
          <a class="btn btn-wa btn-sm" href="${escapeHtml(waLink(store.whatsapp, 'مرحباً، وصلت لكم عبر سوق حفر الباطن'))}" target="_blank" rel="noopener">واتساب</a>
        </div>` : ''}
      </div>
    </article>`;
}

/* -------------------------------- الإعلانات -------------------------------- */

function renderBanners(banners) {
  if (!banners || !banners.length) return '';

  const slides = banners
    .map((b, i) => {
      const link = safeHref(b.link);
      const external = /^https?:/i.test(link);
      const attrs = external ? 'target="_blank" rel="noopener noreferrer"' : '';
      const image = safeImage(b.image);
      const media = image
        ? `<div class="banner-media" style="background-image:url('${escapeHtml(image)}')"></div>`
        : '';
      return `
        <a class="banner-slide theme-${escapeHtml(b.theme || 'emerald')}" href="${escapeHtml(link)}" ${attrs} aria-label="${escapeHtml(b.title)}">
          ${media}
          <div class="banner-content">
            <span class="banner-eyebrow">إعلان</span>
            <h2>${escapeHtml(b.title)}</h2>
            ${b.subtitle ? `<p>${escapeHtml(b.subtitle)}</p>` : ''}
            ${b.cta ? `<span class="banner-cta">${escapeHtml(b.cta)} ${ICONS.arrow}</span>` : ''}
          </div>
        </a>`;
    })
    .join('');

  const dots = banners
    .map((b, i) => `<button class="banner-dot ${i === 0 ? 'active' : ''}" data-banner-dot="${i}" aria-label="الإعلان ${i + 1}"></button>`)
    .join('');

  return `
    <section class="banners" id="banners" aria-label="إعلانات">
      <div class="banner-track" id="bannerTrack">${slides}</div>
      ${banners.length > 1 ? `
        <div class="banner-dots" id="bannerDots">${dots}</div>
        <button class="banner-nav prev" data-banner-nav="-1" aria-label="السابق">${ICONS.arrow}</button>
        <button class="banner-nav next" data-banner-nav="1" aria-label="التالي">${ICONS.arrow.replace('M14 6l-6 6 6 6', 'M10 6l6 6-6 6')}</button>
      ` : ''}
    </section>`;
}

let bannerTimer = null;
let bannerObserver = null;
let bannerVisible = true;

function initBanners() {
  if (bannerTimer) clearInterval(bannerTimer);
  if (bannerObserver) bannerObserver.disconnect();
  bannerTimer = null;

  const track = $('#bannerTrack');
  if (!track) return;

  const slides = Array.from(track.children);
  const dots = $$('.banner-dot');
  if (slides.length < 2) return;

  let index = 0;
  let paused = false;

  const paintDots = () => dots.forEach((d, n) => d.classList.toggle('active', n === index));

  const goTo = (next, smooth = true) => {
    index = (next + slides.length) % slides.length;
    const slide = slides[index];
    const left = slide.offsetLeft - track.offsetLeft;
    try {
      track.scrollTo({ left, behavior: smooth ? 'smooth' : 'auto' });
    } catch (err) {
      track.scrollLeft = left;
    }
    paintDots();
  };

  // مزامنة النقطة النشطة مع التمرير اليدوي (سحب بالإصبع)
  let scrollTimer = null;
  track.addEventListener('scroll', () => {
    clearTimeout(scrollTimer);
    scrollTimer = setTimeout(() => {
      const box = track.getBoundingClientRect();
      const center = box.left + box.width / 2;
      let best = 0;
      let bestDist = Infinity;
      slides.forEach((s, i) => {
        const r = s.getBoundingClientRect();
        const dist = Math.abs(r.left + r.width / 2 - center);
        if (dist < bestDist) {
          bestDist = dist;
          best = i;
        }
      });
      index = best;
      paintDots();
    }, 120);
  }, { passive: true });

  const start = () => {
    if (bannerTimer) clearInterval(bannerTimer);
    bannerTimer = setInterval(() => {
      if (paused || !bannerVisible) return;
      goTo(index + 1);
    }, 5500);
  };

  const pause = () => { paused = true; };
  const resume = () => { paused = false; };

  const banners = $('#banners');
  banners.addEventListener('pointerenter', pause);
  banners.addEventListener('pointerleave', resume);
  banners.addEventListener('focusin', pause);
  banners.addEventListener('focusout', resume);

  $$('[data-banner-dot]').forEach((dot) => {
    dot.addEventListener('click', (e) => {
      e.preventDefault();
      goTo(Number(dot.dataset.bannerDot));
    });
  });

  $$('[data-banner-nav]').forEach((btn) => {
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      goTo(index + Number(btn.dataset.bannerNav));
    });
  });

  // إيقاف التشغيل التلقائي عندما يكون الإعلان خارج الشاشة
  if ('IntersectionObserver' in window) {
    bannerObserver = new IntersectionObserver((entries) => {
      bannerVisible = entries[0].isIntersecting;
    }, { threshold: 0.35 });
    bannerObserver.observe(banners);
  }

  start();
}

/* --------------------------------- الصفحات -------------------------------- */

function filteredProducts() {
  const { cat, district, q, sort } = state.filters;
  const term = q.trim().toLowerCase();

  let list = state.data.products.slice();

  if (cat) list = list.filter((p) => p.categoryId === cat || storeOf(p.storeId)?.categoryId === cat);
  if (district) list = list.filter((p) => storeOf(p.storeId)?.districtId === district);

  if (term) {
    list = list.filter((p) => {
      const store = storeOf(p.storeId);
      const d = districtOf(store?.districtId);
      return (
        p.name.toLowerCase().includes(term) ||
        (store?.name || '').toLowerCase().includes(term) ||
        (d?.name || '').toLowerCase().includes(term)
      );
    });
  }

  if (sort === 'cheap') list.sort((a, b) => a.price - b.price);
  else if (sort === 'expensive') list.sort((a, b) => b.price - a.price);
  else list.sort((a, b) => String(b.createdAt).localeCompare(String(a.createdAt)));

  return list;
}

function filteredStores() {
  const { cat, district, q } = state.filters;
  const term = q.trim().toLowerCase();
  let list = state.data.stores.slice();
  if (cat) list = list.filter((s) => s.categoryId === cat);
  if (district) list = list.filter((s) => s.districtId === district);
  if (term) {
    list = list.filter(
      (s) =>
        s.name.toLowerCase().includes(term) ||
        (districtOf(s.districtId)?.name || '').toLowerCase().includes(term) ||
        (categoryOf(s.categoryId)?.name || '').toLowerCase().includes(term)
    );
  }
  return list.sort((a, b) => Number(b.featured) - Number(a.featured) || a.name.localeCompare(b.name, 'ar'));
}

function renderHome() {
  const { products, stores, categories, districts, banners } = state.data;
  const featuredStores = stores.filter((s) => s.featured).slice(0, 4);
  const visible = filteredProducts();
  const searching = state.filters.q.trim().length > 0 || state.filters.cat || state.filters.district;

  $('#view').innerHTML = `
    ${renderBanners(banners)}

    <nav class="cat-rail" aria-label="الأقسام">
      <button class="cat-tile ${state.filters.cat === '' ? 'active' : ''}" data-filter="cat" data-value="">
        <span class="bubble">🏷️</span>
        <span class="label">الكل</span>
      </button>
      ${categories
        .map(
          (c) => `<button class="cat-tile ${state.filters.cat === c.id ? 'active' : ''}" data-filter="cat" data-value="${escapeHtml(c.id)}">
            <span class="bubble">${catIconMarkup(c)}</span>
            <span class="label">${escapeHtml(c.name)}</span>
          </button>`
        )
        .join('')}
    </nav>

    ${
      !searching && featuredStores.length
        ? `<section class="section">
             <div class="section-head">
               <div>
                 <span class="eyebrow">اكتشف</span>
                 <h2>محلات مميزة</h2>
               </div>
               <a href="#/stores">كل المحلات ${ICONS.arrow}</a>
             </div>
             <div class="grid" style="grid-template-columns:repeat(auto-fill,minmax(300px,1fr))">
               ${featuredStores.map((s) => storeCard(s, false)).join('')}
             </div>
           </section>`
        : ''
    }

    <section class="section" id="products">
      <div class="section-head">
        <div>
          <span class="eyebrow">${searching ? 'نتائج البحث' : 'تسوق الآن'}</span>
          <h2>${searching ? 'المنتجات المطابقة' : 'أحدث المنتجات'}</h2>
          <div class="section-sub">${visible.length} منتج من ${stores.length} محل</div>
        </div>
        <select class="sort-select" id="sortSelect" aria-label="الترتيب">
          <option value="new" ${state.filters.sort === 'new' ? 'selected' : ''}>الأحدث</option>
          <option value="cheap" ${state.filters.sort === 'cheap' ? 'selected' : ''}>الأرخص</option>
          <option value="expensive" ${state.filters.sort === 'expensive' ? 'selected' : ''}>الأغلى</option>
        </select>
      </div>

      <div class="chips" aria-label="الأحياء">
        <button class="chip ${state.filters.district === '' ? 'active' : ''}" data-filter="district" data-value="">كل الأحياء</button>
        ${districts
          .map(
            (d) => `<button class="chip ${state.filters.district === d.id ? 'active' : ''}" data-filter="district" data-value="${escapeHtml(d.id)}">${escapeHtml(d.name)}</button>`
          )
          .join('')}
      </div>

      ${
        visible.length
          ? `<div class="grid">${visible.map(productCard).join('')}</div>`
          : `<div class="empty"><div class="big">🔍</div><h3>ما لقينا نتائج</h3><p>جرّب كلمة ثانية أو أزل الفلاتر.</p></div>`
      }
    </section>

    ${
      !searching
        ? `<section class="submit-band">
             <div class="submit-band-text">
               <span class="eyebrow">للتجار وأصحاب المحلات</span>
               <h2>عندك منتج تبي تعرضه؟</h2>
               <p>أرسل صورة المنتج وسعره، وإدارة السوق تراجعه وتنشره في مكانه المناسب.</p>
             </div>
             <button class="btn btn-primary" data-action="submit-product">أضف منتجك</button>
           </section>`
        : ''
    }

    ${
      !searching
        ? `<section class="section">
             <div class="section-head">
               <div>
                 <span class="eyebrow">المحلات</span>
                 <h2>كل المحلات</h2>
               </div>
               <a href="#/stores">عرض الكل ${ICONS.arrow}</a>
             </div>
             <div class="grid" style="grid-template-columns:repeat(auto-fill,minmax(300px,1fr))">
               ${filteredStores().slice(0, 6).map((s) => storeCard(s, false)).join('')}
             </div>
           </section>`
        : ''
    }
  `;

  bindHomeEvents();
  initBanners();
}

function renderStores() {
  const list = filteredStores();
  $('#view').innerHTML = `
    <div style="margin-top:26px">
      <span class="eyebrow">دليل المحلات</span>
      <h1 style="font-size:24px;font-weight:700;letter-spacing:-.02em">كل محلات حفر الباطن</h1>
      <p style="color:var(--muted);font-size:13.5px;margin-top:4px">${list.length} محل مشترك</p>
    </div>

    <div class="chips" style="margin-top:16px" aria-label="الأقسام">
      <button class="chip ${state.filters.cat === '' ? 'active' : ''}" data-filter="cat" data-value="">كل الأقسام</button>
      ${state.data.categories
        .map(
          (c) =>
            `<button class="chip ${state.filters.cat === c.id ? 'active' : ''}" data-filter="cat" data-value="${escapeHtml(c.id)}">${c.image ? `<img class="chip-img" src="${escapeHtml(c.image)}" alt="">` : escapeHtml(c.icon || '')} ${escapeHtml(c.name)}</button>`
        )
        .join('')}
    </div>

    <div class="chips" aria-label="الأحياء">
      <button class="chip ${state.filters.district === '' ? 'active' : ''}" data-filter="district" data-value="">كل الأحياء</button>
      ${state.data.districts
        .map(
          (d) =>
            `<button class="chip ${state.filters.district === d.id ? 'active' : ''}" data-filter="district" data-value="${escapeHtml(d.id)}">${escapeHtml(d.name)}</button>`
        )
        .join('')}
    </div>

    <div class="grid" style="grid-template-columns:repeat(auto-fill,minmax(300px,1fr));margin-top:8px">
      ${list.length ? list.map((s) => storeCard(s, true)).join('') : `<div class="empty"><div class="big">🏬</div><h3>لا توجد محلات</h3><p>جرّب قسم أو حي مختلف.</p></div>`}
    </div>
  `;

  $$('[data-filter]').forEach((btn) => {
    btn.addEventListener('click', () => {
      state.filters[btn.dataset.filter] = btn.dataset.value;
      renderStores();
    });
  });
}

function renderStore(id) {
  const store = storeOf(id);
  const view = $('#view');

  if (!store) {
    view.innerHTML = `<div class="empty" style="margin-top:40px"><div class="big">🏬</div><h3>المحل غير متوفر</h3><p>قد يكون الاشتراك منتهياً أو تم إيقافه.</p><a class="btn btn-primary" href="#/stores" style="margin-top:14px">تصفح المحلات</a></div>`;
    return;
  }

  const district = districtOf(store.districtId);
  const cat = categoryOf(store.categoryId);
  const items = state.data.products.filter((p) => p.storeId === store.id);
  const coverImage = safeImage(store.cover);
  const coverStyle = coverImage ? `background-image:url('${escapeHtml(coverImage)}')` : '';
  const storeLogo = safeImage(store.logo);
  const logo = storeLogo
    ? `<img src="${escapeHtml(storeLogo)}" alt="${escapeHtml(store.name)}">`
    : escapeHtml(store.name.slice(0, 1));

  view.innerHTML = `
    <a class="back-link" href="#/stores">${ICONS.arrow} كل المحلات</a>

    <section class="store-hero">
      <div class="store-cover" style="${coverStyle}"></div>
      <div class="store-head">
        <div class="store-logo">${logo}</div>
        <div class="store-head-text">
          <h1>${escapeHtml(store.name)} ${store.featured ? '<span class="star">مميز</span>' : ''}</h1>
          <p>${escapeHtml(cat?.name || '')} • ${escapeHtml(district?.name || '')} • ${items.length} منتج</p>
        </div>
      </div>
      ${store.description ? `<p style="padding:0 20px 14px;color:var(--muted);font-size:13.5px">${escapeHtml(store.description)}</p>` : ''}
      <div class="store-actions">
        <a class="btn btn-primary" href="${escapeHtml(waLink(store.whatsapp, `مرحباً ${store.name}، وصلت لكم عبر سوق حفر الباطن`))}" target="_blank" rel="noopener">${ICONS.wa} واتساب المحل</a>
        <div class="store-actions-more">
          ${store.mapsUrl ? `<a class="btn btn-ghost" href="${escapeHtml(safeHref(store.mapsUrl))}" target="_blank" rel="noopener noreferrer">📍 على الخريطة</a>` : ''}
          ${store.phone ? `<a class="btn btn-ghost" href="tel:${escapeHtml(store.phone)}">📞 ${escapeHtml(store.phone)}</a>` : ''}
          <button class="btn btn-ghost" data-action="submit-product" data-id="${escapeHtml(store.id)}">➕ أضف منتجك</button>
        </div>
      </div>
    </section>

    <section class="section">
      <div class="section-head">
        <div>
          <span class="eyebrow">منتجات المحل</span>
          <h2>${items.length} منتج</h2>
        </div>
      </div>
      ${
        items.length
          ? `<div class="grid">${items.map(productCard).join('')}</div>`
          : `<div class="empty"><div class="big">📦</div><h3>لا توجد منتجات معروضة</h3><p>تواصل مع المحل عبر واتساب للاستفسار.</p></div>`
      }
    </section>
  `;
}

/* -------------------------------- الأحداث --------------------------------- */

function bindHomeEvents() {
  $$('[data-filter]').forEach((btn) => {
    btn.addEventListener('click', () => {
      state.filters[btn.dataset.filter] = btn.dataset.value;
      renderHome();
      if (btn.dataset.filter !== 'cat') {
        document.getElementById('products')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    });
  });

  const sort = $('#sortSelect');
  if (sort) {
    sort.addEventListener('change', () => {
      state.filters.sort = sort.value;
      renderHome();
    });
  }
}

function setSearch(value) {
  state.filters.q = value;
  [$('#searchInput'), $('#searchInputMobile')].forEach((input) => {
    if (input && input.value !== value) input.value = value;
  });
  if (location.hash && location.hash !== '#/') {
    location.hash = '#/';
  } else {
    renderHome();
  }
}

/* -------------------------------- المودال --------------------------------- */

function openModal(html) {
  closeModal();
  const wrap = document.createElement('div');
  wrap.className = 'modal';
  wrap.id = 'modalWrap';
  wrap.innerHTML = `<div class="modal-card">${html}</div>`;
  document.body.appendChild(wrap);

  wrap.addEventListener('click', (e) => {
    if (e.target === wrap || e.target.dataset.action === 'close-modal') closeModal();
  });
  return wrap;
}

function closeModal() {
  document.getElementById('modalWrap')?.remove();
}

function openProduct(id) {
  const product = productOf(id);
  if (!product) return;
  const store = storeOf(product.storeId);
  const district = districtOf(store?.districtId);
  const cat = categoryOf(product.categoryId) || categoryOf(store?.categoryId);
  const msg = `مرحباً ${store?.name || ''}، أرغب بالاستفسار عن: ${product.name} (${money(product.price)} ر.س) — عبر سوق حفر الباطن`;

  openModal(`
    <div class="thumb" style="border-radius:16px;margin-bottom:16px;aspect-ratio:16/11">
      ${thumbMarkup(product.image, iconOf(product), product.name)}
    </div>
    <h3 style="text-align:start">${escapeHtml(product.name)}</h3>
    <p style="text-align:start;margin-top:2px">${escapeHtml(store?.name || '')} • ${escapeHtml(district?.name || '')} • ${escapeHtml(cat?.name || '')}</p>
    <div class="price-row" style="justify-content:flex-start;gap:8px;margin:14px 0">
      <span class="price" style="font-size:23px">${money(product.price)} <small>ر.س</small></span>
      ${product.oldPrice > product.price ? `<span class="price-old">${money(product.oldPrice)}</span>` : ''}
    </div>
    ${product.description ? `<p style="text-align:start;margin-bottom:16px">${escapeHtml(product.description)}</p>` : ''}
    <div class="modal-actions">
      <button class="btn btn-primary btn-block" data-action="add" data-id="${escapeHtml(product.id)}">${ICONS.plus} أضف إلى السلة</button>
      <a class="btn btn-wa btn-block" href="${escapeHtml(waLink(store?.whatsapp, msg))}" target="_blank" rel="noopener">${ICONS.wa} استفسر عبر واتساب</a>
      <a class="btn btn-ghost btn-block" href="#/store/${escapeHtml(store?.id || '')}" data-action="close-modal">زيارة صفحة المحل</a>
    </div>
  `);
}

/* ----------------------------- إضافة منتج للوحة ---------------------------- */

async function uploadSubmissionImage(file) {
  if (file.size > 3 * 1024 * 1024) throw new Error('حجم الصورة أكبر من ٣ ميجا');
  const dataUrl = await new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
  const res = await fetch('/api/submission-upload', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ data: dataUrl })
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || 'تعذر رفع الصورة');
  return data.url;
}

function openSubmissionForm(storeId) {
  const stores = state.data.stores || [];
  if (!stores.length) return toast('لا توجد محلات متاحة حالياً');

  const selectedStore = storeId || stores[0].id;
  const categories = state.data.categories || [];

  const wrap = openModal(`
    <h3 style="text-align:start">أضف منتجك للمنصة</h3>
    <p style="text-align:start;margin-bottom:14px">أرسل تفاصيل منتج جديد أو صورة لمنتج موجود، والإدارة تراجع الطلب قبل النشر.</p>
    <form id="submissionForm" style="text-align:start">
      <div class="seg" role="group" aria-label="نوع الطلب">
        <button type="button" class="seg-btn active" data-sub-type="product">📦 منتج جديد</button>
        <button type="button" class="seg-btn" data-sub-type="image">🖼️ صورة منتج موجود</button>
      </div>
      <input type="hidden" name="type" value="product">

      <div class="field">
        <label for="subStore">المحل *</label>
        <select id="subStore" name="storeId" required>
          ${stores.map((s) => `<option value="${escapeHtml(s.id)}" ${s.id === selectedStore ? 'selected' : ''}>${escapeHtml(s.name)}</option>`).join('')}
        </select>
      </div>

      <div class="form-grid-2">
        <div class="field"><label for="subName">اسمك *</label><input id="subName" name="customerName" required maxlength="60" placeholder="اسمك"></div>
        <div class="field"><label for="subPhone">رقم جوالك *</label><input id="subPhone" name="phone" type="tel" inputmode="tel" required maxlength="20" placeholder="05xxxxxxxx"></div>
      </div>

      <div data-sub-fields="product">
        <div class="field"><label for="subProductName">اسم المنتج *</label><input id="subProductName" name="name" maxlength="120" placeholder="مثال: عطر عود فاخر"></div>
        <div class="form-grid-2">
          <div class="field"><label for="subPrice">السعر (ر.س) *</label><input id="subPrice" name="price" type="number" min="0" step="0.01" placeholder="0"></div>
          <div class="field"><label for="subCat">القسم</label><select id="subCat" name="categoryId">${categories.map((c) => `<option value="${escapeHtml(c.id)}">${escapeHtml(c.name)}</option>`).join('')}</select></div>
        </div>
        <div class="field"><label for="subDesc">وصف قصير</label><textarea id="subDesc" name="description" rows="2" maxlength="500" placeholder="تفاصيل المنتج…"></textarea></div>
      </div>

      <div data-sub-fields="image" hidden>
        <div class="field">
          <label for="subProduct">المنتج الموجود *</label>
          <select id="subProduct" name="productId"></select>
        </div>
      </div>

      <div class="field">
        <label>صورة المنتج <span id="subImageReq" hidden style="color:var(--danger)">*</span></label>
        <div class="upload-box">
          <div class="upload-preview" id="subPreview">🖼️</div>
          <label class="btn btn-ghost btn-sm upload-btn">اختر صورة
            <input type="file" id="subImageFile" accept="image/png,image/jpeg,image/webp">
          </label>
          <span class="field-hint" id="subUploadHint">اختيارية للمنتج الجديد</span>
        </div>
        <input type="hidden" name="image" id="subImageUrl">
      </div>

      <div class="field"><label for="subNote">ملاحظة للإدارة</label><textarea id="subNote" name="note" rows="2" maxlength="400" placeholder="أي تفاصيل إضافية…"></textarea></div>

      <div class="modal-actions">
        <button class="btn btn-primary btn-block" type="submit">إرسال الطلب للمراجعة</button>
        <button class="btn btn-ghost btn-block" type="button" data-action="close-modal">إلغاء</button>
      </div>
    </form>
  `);

  const form = $('#submissionForm', wrap);
  const typeInput = form.elements.namedItem('type');
  const productFields = form.querySelector('[data-sub-fields="product"]');
  const imageFields = form.querySelector('[data-sub-fields="image"]');
  const storeSelect = form.elements.namedItem('storeId');
  const productSelect = form.elements.namedItem('productId');
  const catSelect = form.elements.namedItem('categoryId');
  const nameInput = form.elements.namedItem('name');
  const priceInput = form.elements.namedItem('price');
  const imageReq = form.querySelector('#subImageReq');
  const uploadHint = form.querySelector('#subUploadHint');
  let uploading = false;

  const refreshProducts = () => {
    const products = state.data.products.filter((p) => p.storeId === storeSelect.value);
    productSelect.innerHTML = products.length
      ? products.map((p) => `<option value="${escapeHtml(p.id)}">${escapeHtml(p.name)} — ${money(p.price)} ر.س</option>`).join('')
      : '<option value="">لا توجد منتجات في هذا المحل</option>';
    const store = storeOf(storeSelect.value);
    if (store && catSelect) catSelect.value = store.categoryId || catSelect.value;
  };

  const setType = (type) => {
    typeInput.value = type;
    productFields.hidden = type !== 'product';
    imageFields.hidden = type !== 'image';
    nameInput.required = type === 'product';
    priceInput.required = type === 'product';
    productSelect.required = type === 'image';
    imageReq.hidden = type !== 'image';
    uploadHint.textContent = type === 'image' ? 'مطلوبة لتحديث صورة المنتج' : 'اختيارية للمنتج الجديد';
    $$('.seg-btn', form).forEach((btn) => btn.classList.toggle('active', btn.dataset.subType === type));
  };

  $$('.seg-btn', form).forEach((btn) => {
    btn.addEventListener('click', () => setType(btn.dataset.subType));
  });
  storeSelect.addEventListener('change', refreshProducts);
  refreshProducts();

  form.querySelector('#subImageFile').addEventListener('change', async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const preview = form.querySelector('#subPreview');
    uploading = true;
    preview.innerHTML = '<span style="font-size:11px">…</span>';
    uploadHint.textContent = 'جاري الرفع…';
    try {
      const url = await uploadSubmissionImage(file);
      form.elements.namedItem('image').value = url;
      preview.innerHTML = `<img src="${escapeHtml(url)}" alt="">`;
      uploadHint.textContent = 'تم رفع الصورة ✓';
    } catch (err) {
      preview.textContent = '🖼️';
      uploadHint.textContent = 'اختيارية للمنتج الجديد';
      toast(err.message);
    } finally {
      uploading = false;
    }
  });

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    if (uploading) return toast('انتظر اكتمال رفع الصورة');
    const type = typeInput.value;
    const btn = form.querySelector('button[type="submit"]');
    const payload = {
      type,
      storeId: storeSelect.value,
      customerName: form.elements.namedItem('customerName').value,
      phone: form.elements.namedItem('phone').value,
      note: form.elements.namedItem('note').value,
      image: form.elements.namedItem('image').value
    };
    if (type === 'product') {
      payload.name = nameInput.value;
      payload.price = priceInput.value;
      payload.categoryId = catSelect.value;
      payload.description = form.elements.namedItem('description').value;
    } else {
      payload.productId = productSelect.value;
      payload.name = (productSelect.options[productSelect.selectedIndex]?.textContent || '').split('—')[0].trim();
    }

    btn.disabled = true;
    btn.textContent = 'جاري الإرسال…';
    try {
      const res = await fetch('/api/submissions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(data.error || 'تعذر إرسال الطلب');
      closeModal();
      showSubmissionSuccess(payload);
    } catch (err) {
      btn.disabled = false;
      btn.textContent = 'إرسال الطلب للمراجعة';
      toast(err.message);
    }
  });
}

function showSubmissionSuccess(payload) {
  const text = `طلب إضافة ${payload.type === 'image' ? 'صورة منتج' : 'منتج'} في سوق حفر الباطن\nالمحل: ${storeOf(payload.storeId)?.name || ''}\nالمنتج: ${payload.name || ''}\nالسعر: ${payload.price || ''}\nالجوال: ${payload.phone}`;
  openModal(`
    <div class="modal-icon">✅</div>
    <h3>تم إرسال طلبك</h3>
    <p>استلمنا طلبك وسيراجعه فريق سوق حفر الباطن قبل النشر. بنتواصل معك عبر واتساب إذا احتجنا تفاصيل إضافية.</p>
    <div class="modal-actions">
      <a class="btn btn-wa btn-block" href="${escapeHtml(waLink(state.data.settings.supportWhatsapp, text))}" target="_blank" rel="noopener">إرسال نسخة للدعم</a>
      <button class="btn btn-ghost btn-block" data-action="close-modal">تم</button>
    </div>
  `);
}

/* --------------------------------- السلة ---------------------------------- */

function renderCart() {
  const body = $('#cartBody');
  const foot = $('#cartFoot');
  if (!body) return;

  if (!state.cart.length) {
    body.innerHTML = `<div class="empty"><div class="big">🛒</div><h3>السلة فاضية</h3><p>أضف منتجات من المحلات وابدأ طلبك.</p></div>`;
    foot.innerHTML = '';
    renderCartBadge();
    return;
  }

  body.innerHTML = state.cart
    .map((line) => {
      const product = productOf(line.productId);
      if (!product) return '';
      const store = storeOf(product.storeId);
      return `
        <div class="cart-line">
          <div class="cart-thumb">${thumbMarkup(product.image, iconOf(product), product.name)}</div>
          <div class="cart-info">
            <div class="cart-name">${escapeHtml(product.name)}</div>
            <div class="cart-store">${escapeHtml(store?.name || '')}</div>
            <div class="qty">
              <button data-action="dec" data-id="${escapeHtml(product.id)}" aria-label="تقليل">−</button>
              <span>${line.qty}</span>
              <button data-action="inc" data-id="${escapeHtml(product.id)}" aria-label="زيادة">+</button>
            </div>
          </div>
          <div class="cart-side">
            <div class="cart-price">${money(product.price * line.qty)} ر.س</div>
            <button class="remove" data-action="remove" data-id="${escapeHtml(product.id)}">حذف</button>
          </div>
        </div>`;
    })
    .join('');

  foot.innerHTML = `
    <div class="total-row"><span>الإجمالي</span><strong>${money(cartTotal())} ر.س</strong></div>
    <button class="btn btn-primary btn-block" data-action="checkout">إتمام الطلب</button>
  `;

  renderCartBadge();
}

function renderCheckoutForm() {
  const stores = [...new Set(state.cart.map((l) => productOf(l.productId)?.storeId).filter(Boolean))]
    .map((id) => storeOf(id))
    .filter(Boolean);

  const wrap = openModal(`
    <h3>تأكيد الطلب</h3>
    <p>${stores.length === 1 ? 'طلبك من: ' + escapeHtml(stores[0].name) : 'طلبك من ' + stores.length + ' محلات'}</p>
    <form id="checkoutForm" style="text-align:start">
      <div class="field">
        <label for="cName">الاسم</label>
        <input id="cName" name="name" placeholder="اسمك" required maxlength="60">
      </div>
      <div class="field">
        <label for="cPhone">رقم الجوال</label>
        <input id="cPhone" name="phone" type="tel" inputmode="tel" placeholder="05xxxxxxxx" required maxlength="20">
      </div>
      <div class="field">
        <label for="cNote">ملاحظات (اختياري)</label>
        <textarea id="cNote" name="note" rows="2" maxlength="400" placeholder="مثال: أبغى التوصيل بعد المغرب"></textarea>
      </div>
      <div class="total-row"><span>الإجمالي</span><strong>${money(cartTotal())} ر.س</strong></div>
      <div class="modal-actions">
        <button class="btn btn-primary btn-block" type="submit">تأكيد الطلب</button>
        <button class="btn btn-ghost btn-block" type="button" data-action="close-modal">رجوع</button>
      </div>
    </form>
  `);

  $('#checkoutForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const form = e.target;
    const submitBtn = form.querySelector('button[type="submit"]');
    submitBtn.disabled = true;
    submitBtn.textContent = 'جاري الإرسال…';

    try {
      const res = await fetch('/api/orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          customerName: form.elements.namedItem('name').value,
          phone: form.elements.namedItem('phone').value,
          note: form.elements.namedItem('note').value,
          items: state.cart.map((l) => ({ productId: l.productId, qty: l.qty }))
        })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'تعذر إرسال الطلب');

      state.cart = [];
      saveCart();
      renderCart();
      showOrderSuccess(data.order);
    } catch (err) {
      submitBtn.disabled = false;
      submitBtn.textContent = 'تأكيد الطلب';
      toast(err.message);
    }
  });
}

function showOrderSuccess(order) {
  const byStore = {};
  order.items.forEach((item) => {
    if (!byStore[item.storeId]) byStore[item.storeId] = [];
    byStore[item.storeId].push(item);
  });

  const waButtons = Object.keys(byStore)
    .map((storeId) => {
      const store = storeOf(storeId);
      const lines = byStore[storeId]
        .map((i) => `• ${i.name} × ${i.qty} = ${money(i.price * i.qty)} ر.س`)
        .join('\n');
      const text = `طلب جديد رقم ${order.number}\nالاسم: ${order.customerName}\nالجوال: ${order.phone}\n\n${lines}\n\nالإجمالي: ${money(order.total)} ر.س\n(عبر سوق حفر الباطن)`;
      return `<a class="btn btn-wa btn-block" href="${escapeHtml(waLink(store?.whatsapp, text))}" target="_blank" rel="noopener">إرسال الطلب لـ ${escapeHtml(store?.name || 'المحل')}</a>`;
    })
    .join('');

  openModal(`
    <div class="modal-icon">✅</div>
    <h3>تم استلام طلبك</h3>
    <div class="order-number">${escapeHtml(order.number)}</div>
    <p>حفظنا طلبك، وبإمكانك إرساله للمحل عبر واتساب مباشرة لتأكيد التفاصيل.</p>
    <div class="modal-actions">
      ${waButtons}
      <button class="btn btn-ghost btn-block" data-action="close-modal">تم</button>
    </div>
  `);
}

function openCart() {
  $('#cartDrawer').classList.add('open');
  $('#cartDrawer').setAttribute('aria-hidden', 'false');
  $('#overlay').hidden = false;
  document.body.style.overflow = 'hidden';
  renderCart();
}

function closeCart() {
  $('#cartDrawer').classList.remove('open');
  $('#cartDrawer').setAttribute('aria-hidden', 'true');
  $('#overlay').hidden = true;
  document.body.style.overflow = '';
}

/* -------------------------------- التوجيه --------------------------------- */

function setActiveNav(hash) {
  const active = hash === '#/stores' || hash.startsWith('#/store/') ? 'stores' : 'home';
  $$('[data-nav]').forEach((el) => el.classList.toggle('active', el.dataset.nav === active));
}

function router() {
  const hash = location.hash || '#/';
  closeModal();

  if (hash.startsWith('#/store/')) {
    renderStore(hash.replace('#/store/', '').split('?')[0]);
  } else if (hash === '#/stores') {
    renderStores();
  } else {
    renderHome();
  }

  setActiveNav(hash);
  window.scrollTo({ top: 0, behavior: 'auto' });
}

/** إعادة رسم الصفحة الحالية دون قفز للأعلى أو إغلاق النوافذ. */
function rerenderCurrent() {
  const hash = location.hash || '#/';
  if (hash.startsWith('#/store/')) {
    renderStore(hash.replace('#/store/', '').split('?')[0]);
  } else if (hash === '#/stores') {
    renderStores();
  } else {
    renderHome();
  }
  setActiveNav(hash);
}

/** يتحقق دورياً من تعديلات لوحة التحكم ويحدّث صفحة الزائر تلقائياً. */
async function checkForUpdates() {
  if (document.hidden || state.refreshing || !state.data) return;
  if (document.querySelector('.modal')) return;
  if ($('#cartDrawer')?.getAttribute('aria-hidden') === 'false') return;

  try {
    const res = await fetch('/api/revision', { cache: 'no-store' });
    if (!res.ok) return;
    const { revision } = await res.json();
    if (!revision || revision === state.revision) return;

    state.refreshing = true;
    const full = await fetch('/api/bootstrap', { cache: 'no-store' });
    if (!full.ok) return;
    const data = await full.json();

    state.data = data;
    state.revision = data.revision || revision;
    applySiteSettings(data.settings);
    rerenderCurrent();
    renderCartBadge();
  } catch (err) {
    /* تجاهل أخطاء الشبكة المؤقتة */
  } finally {
    state.refreshing = false;
  }
}

/* -------------------------------- التشغيل --------------------------------- */

async function init() {
  try {
    const res = await fetch('/api/bootstrap', { cache: 'no-store' });
    if (!res.ok) throw new Error('تعذر تحميل البيانات');
    state.data = await res.json();
    state.revision = state.data.revision || 0;
  } catch (err) {
    $('#view').innerHTML = `<div class="empty" style="margin-top:40px"><div class="big">⚠️</div><h3>تعذر الاتصال بالخادم</h3><p>تأكد من تشغيل السيرفر ثم حدّث الصفحة.</p></div>`;
    return;
  }

  applySiteSettings(state.data.settings);
  $('#year').textContent = new Date().getFullYear();

  renderCartBadge();
  router();

  window.addEventListener('hashchange', router);
  setInterval(checkForUpdates, 30000);
  document.addEventListener('visibilitychange', () => {
    if (!document.hidden) checkForUpdates();
  });

  /* بحث */
  $('#topSearch').addEventListener('submit', (e) => {
    e.preventDefault();
    setSearch($('#searchInput').value);
  });

  $('#searchInput').addEventListener('input', (e) => setSearch(e.target.value));
  $('#searchInputMobile').addEventListener('input', (e) => setSearch(e.target.value));

  $('#searchToggle').addEventListener('click', () => {
    const bar = $('#searchbar');
    bar.hidden = !bar.hidden;
    if (!bar.hidden) $('#searchInputMobile').focus();
  });

  /* سلة */
  $('#cartBtn').addEventListener('click', openCart);
  $('#navCart').addEventListener('click', openCart);
  $('#navSearch').addEventListener('click', () => {
    const bar = $('#searchbar');
    bar.hidden = false;
    $('#searchInputMobile').focus();
  });
  $('#closeCart').addEventListener('click', closeCart);
  $('#overlay').addEventListener('click', closeCart);

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      closeModal();
      closeCart();
    }
  });

  /* تفويض أحداث الأزرار */
  document.addEventListener('click', (e) => {
    const btn = e.target.closest('[data-action]');
    if (!btn) return;
    const action = btn.dataset.action;
    const id = btn.dataset.id;

    if (action === 'add') {
      e.preventDefault();
      addToCart(id);
      if (btn.closest('.modal')) {
        closeModal();
        openCart();
      }
    } else if (action === 'open-product') {
      openProduct(id);
    } else if (action === 'submit-product') {
      e.preventDefault();
      openSubmissionForm(id);
    } else if (action === 'inc') {
      changeQty(id, 1);
    } else if (action === 'dec') {
      changeQty(id, -1);
    } else if (action === 'remove') {
      removeFromCart(id);
    } else if (action === 'checkout') {
      if (!state.cart.length) return toast('السلة فاضية');
      closeCart();
      renderCheckoutForm();
    } else if (action === 'close-modal') {
      closeModal();
    }
  });
}

init();
